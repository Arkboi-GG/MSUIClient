﻿using System.Numerics;
using System.Diagnostics;
using ImGuiNET;
using Silk.NET.Input;
using Silk.NET.OpenGL;
using MSUIClient.Engine;
using MSUIClient.Formats;
using MSUIClient.Player;
using MSUIClient.World;
using MSUIClient.World.Collision;
using MSUIClient.World.Doodads;
using MSUIClient.World.Particles;
using MSUIClient.World.Units;
using MSUIClient.World.Wmo;

namespace MSUIClient;

/// <summary>
/// MSUI Client — native C# client for VMaNGOS 1.12.1 (client build 5875).
///
/// Phase 1: load Northshire straight out of the local MPQs and walk around it.
/// No asset server, no bake, no HTTP, no coordinate conversion.
/// </summary>
public static class Program
{
    public static int Main(string[] args)
    {
        Console.WriteLine("MSUI Client — VMaNGOS 1.12.1 (build 5875)");
        Console.WriteLine();

        ClientConfig config;
        try
        {
            config = ClientConfig.Load(args.Length > 0 ? args[0] : null);
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine($"[config] {ex.Message}");
            return 1;
        }

        Console.WriteLine($"[start] map {config.Start.Map} ({config.Start.MapName}) " +
                          $"at ({config.Start.X:F1}, {config.Start.Y:F1}, {config.Start.Z:F1})");

        // The player's settings are read BEFORE the window exists, because four
        // of them are decided at window creation and cannot be changed after it:
        // the resolution, the requested multisample COUNT, the initial vsync
        // request, and the anisotropy the texture uploader selects once. Those
        // are folded into the ClientConfig the window is about to read.
        // Everything else is pushed onto the live renderers by InitSettings.
        //
        // A missing or corrupt settings.json is not an error - SettingsStore.Load
        // logs a line and starts from the shipped defaults.
        var settings = SettingsStore.Load(config.RepoRoot);
        ApplyStartupSettings(config, settings.Settings);

        // WoW's own UI typeface, straight out of fonts.MPQ. It has to happen
        // before the window exists: ImGui rasterises its glyph atlas when the
        // controller is constructed, and there is no supported way to swap the
        // font afterwards. Null falls back to ImGui's bitmap font.
        using var window = new ClientWindow(config)
        {
            UiFontPath = MSUIClient.Engine.UI.UiFont.Extract(config.ClientDataPath),
            UiFontSize = MSUIClient.Engine.UI.UiFont.SizeFor(config.Window.UiScale),
        };

        var game = new GameLoop(window, config) { SettingsFile = settings };

        window.OnLoad += game.Load;
        window.OnUpdate += game.Update;
        window.OnRender += game.Render;
        window.OnGui += game.Gui;
        window.OnOverlay += game.Overlay;
        window.OnOverlayTop += game.OverlayTop;
        window.OnClosing += game.Dispose;

        try
        {
            window.Run();
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine($"[fatal] {ex}");
            return 2;
        }

        game.Dispose();
        return 0;
    }

    /// <summary>
    /// The restart-scoped half of the settings: values the window and the texture
    /// uploader read once, at creation, and can never be told about again.
    ///
    /// They are folded into ClientConfig rather than read from GameSettings
    /// directly so that exactly one type describes "what this window was built
    /// with" - a second source of truth for the resolution is how a window ends
    /// up disagreeing with itself after a resize.
    /// </summary>
    private static void ApplyStartupSettings(ClientConfig config, GameSettings settings)
    {
        config.Window.Width = Math.Clamp(settings.Display.WindowWidth, 640, 7680);
        config.Window.Height = Math.Clamp(settings.Display.WindowHeight, 480, 4320);
        config.Window.VSync = settings.Display.VSync;
        config.Window.UiScale = Math.Clamp(settings.Display.UiScale, 0.5f, 4f);

        config.Render.MsaaSamples = Math.Clamp(settings.Display.MsaaSamples, 1, 16);
        config.Render.Anisotropy = Math.Clamp(settings.Display.Anisotropy, 1f, 16f);
        config.Render.FieldOfView = Math.Clamp(settings.View.FieldOfView, 30f, 110f);
        config.Render.NearPlane = settings.View.NearPlane;
        config.Render.FarPlane = settings.View.FarPlane;

        config.Start.TileRadius = Math.Clamp(settings.Streaming.TileRadius, 1, 3);
        config.Start.WmoPreloadRadius = Math.Clamp(settings.Streaming.WmoPreloadRadius, 1, 4);
        config.Start.DrainPreloadsAtStartup = settings.Streaming.DrainPreloadsAtStartup;

        Console.WriteLine($"[settings] window {config.Window.Width}x{config.Window.Height} " +
                          $"vsync {(config.Window.VSync ? "on" : "off")} " +
                          $"msaa {config.Render.MsaaSamples}x " +
                          $"aniso {config.Render.Anisotropy:F0}x " +
                          $"ui {config.Window.UiScale:F2}x");
    }
}

/// <summary>
/// Phase 1 loop: a character walking on real terrain, with vmap collision when
/// the vmaps are present.
///
/// The camera orbits the character rather than flying independently — its Target
/// is the character's feet and Camera.EyeHeight lifts the look-at point. Camera
/// yaw is the single source of facing: it feeds straight into the controller as
/// the character's orientation, which is also the value a movement packet wants
/// in Phase 2. Nothing is converted anywhere.
///
/// Free-fly survives as an F-key toggle. It is the fastest way to tell a
/// movement bug from a world bug: if a place looks wrong on foot, fly to it.
/// </summary>
public sealed partial class GameLoop : IDisposable
{
    private readonly ClientWindow _window;
    private readonly ClientConfig _config;

    private TerrainRenderer? _terrain;
    private CharacterController? _controller;
    private CollisionWorld? _collision;
    private VmapCollisionLoader? _vmaps;
    private MpqMount? _mpq;
    private GpuUploadWorker? _uploads;
    private AssetWorkerPool? _assetWorkers;
    private WmoRenderer? _wmo;
    private DoodadRenderer? _doodads;
    private LiquidRenderer? _liquid;

    /// <summary>
    /// Deepest water, in yards above the feet, that still counts as WADING for
    /// the wake (PLAN_16 D3). Past this the character is swimming rather than
    /// walking through it, and a surface trail is the wrong effect.
    ///
    /// Set a little above the eventual swim threshold so the two do not fight at
    /// the margin; PLAN_16 D4 puts that entry around 1.4 yd.
    /// </summary>
    private const float WakeMaxWadeDepth = 1.8f;
    private FoliageRenderer? _foliage;
    private AdtCache? _adts;
    private CollisionDebugRenderer? _collisionDebug;
    private CharacterRenderer? _character;
    private GpuFrameProfiler? _gpuProfiler;
    private readonly WorldAtmosphere _atmosphere = new();

    /// <summary>Last crosshair WMO-group pick result, shown in the HUD.</summary>
    private List<World.Wmo.WmoRenderer.GroupHit> _lastPick = new();

    private bool _cycleTimeOfDay;
    private bool _coupleFarPlaneToFog = true;
    private float _gameHoursPerMinute = 1f;
    private SkyRenderer? _sky;
    private double _worldRenderMilliseconds;
    private double _foliageRenderMilliseconds;

    /// <summary>
    /// The periodic full re-scatter. Zero on the frames that skip it, so an
    /// average over frames is meaningless - read it on the frames it fires.
    /// </summary>
    private double _foliageScatterMilliseconds;
    private ParticleRenderer? _particles;
    private FfxGlow? _glow;
    private double _particleSimulateMilliseconds;
    private double _particleDrawMilliseconds;

    /// <summary>Drawing foliage. Every frame.</summary>
    private double _foliageDrawMilliseconds;

    private double _liquidRenderMilliseconds;
    private double _characterRenderMilliseconds;
    private double _debugRenderMilliseconds;
    private double _updateMilliseconds;
    private double _movementMilliseconds;
    private double _residencyMilliseconds;
    private double _preloadMilliseconds;
    private double _characterUpdateMilliseconds;
    private double _cameraCollisionMilliseconds;

    // Update had three untimed regions at its head. hitch-32-49-3 reported
    // "update 100.3 (move 0.1 resid 0.0 preload 0.0)" - 100 ms inside Update
    // that no sub-timer covered, which is the same lie the [stream] timer told
    // by starting late. Named now, plus an unaccounted residual so a hole here
    // can never hide again.
    private double _pumpPreloadsMilliseconds;
    private double _acceptCollisionMilliseconds;
    private double _doodadCollisionSnapshotMilliseconds;

    // The preload block is four different jobs sharing one timer, and one of
    // them ate 96 ms. Same lesson as every other split so far.
    private double _outdoorPlacementMilliseconds;
    private double _interiorPlacementMilliseconds;
    private int _placementsRequested;
    private double _discoverMilliseconds;
    private double _doodadDemandMilliseconds;
    private double _warmMilliseconds;

    /// <summary>Edge detection for the fly toggle — IsDown reports held, not pressed.</summary>
    private bool _flyKeyDown;
    private bool _collisionKeyDown;
    private bool _pickButtonDown;

    /// <summary>
    /// Draw the character capsule. OFF now that there is a model - the capsule
    /// is drawn solid and on top, so leaving it on hides the thing it was built
    /// to help verify. Tick "Show player capsule" in the HUD to bring it back;
    /// it is still the fastest way to confirm the model stands where the physics
    /// thinks it does.
    /// </summary>
    private bool _showPlayerMarker;

    /// <summary>Keyboard turn rate, radians per second. About 160 degrees a second.</summary>
    private float _turnSpeed = 2.8f;

    /// <summary>Whether the Tier 1 set is on. Toggling re-composites the atlas.</summary>
    private bool _dressed = true;


    /// <summary>Last frame's walk modifier, so the animator can pick Walk over Run.</summary>
    private bool _walking;

    private double _collisionBuildSeconds;
    private Task<(int Generation, CollisionWorld World, double Seconds)>? _collisionBuildTask;
    private int _collisionGeneration;
    // Doodads stream in after the startup collision build, so the initial world
    // has few/none of them. When new placements arrive we flag the collision
    // world dirty and rebuild it (coalesced) so trees/fences become solid.
    private bool _doodadCollisionDirty;

    /// <summary>
    /// Solid doodad placements that have appeared since the last collision
    /// build. A rebuild re-expands the WHOLE world (~509,000 triangles) and
    /// rebuilds the whole BVH (0.4-1.2s of worker time), so doing it for ten
    /// new props is almost pure waste - it re-derives geometry it already had.
    /// Until collision is per-tile and spliced (PLAN_08 D3), requiring a
    /// meaningful delta is the cheap way to stop paying that every few seconds.
    /// </summary>
    private int _doodadCollisionPending;

    /// <summary>New placements needed before a rebuild is worth its cost.</summary>
    private const int DoodadCollisionRebuildThreshold = 96;

    /// <summary>
    /// Rebuild anyway after this long, so a trickle of stragglers still becomes
    /// solid rather than waiting forever below the threshold.
    /// </summary>
    private const float DoodadCollisionMaxDeferSeconds = 15f;

    private float _doodadCollisionDeferredFor;
    private float _doodadCollisionRebuildCooldown;
    private double _lastStreamSeconds;
    private (int col, int row)? _residentCentre;
    private bool _preloadWmoFirst;
    private readonly Queue<(int col, int row)> _backgroundDiscovery = new();
    private Task<AdtTerrainReader.AdtResult?>? _backgroundAdtLoad;
    private (int col, int row) _backgroundAdtTile;
    private float _backgroundDiscoveryDelay = 0.5f;
    private float _doodadDemandDelay;

    /// <summary>
    /// Where the last demand scan ran. The scan re-derives EVERY placement in
    /// residency range - 7,562 of them - plus a LINQ sort over every MODD entry
    /// in radius, and it was doing that four times a second forever, moving or
    /// not, changed or not. That is the "I cross the same spot, nothing changes
    /// visually, and it still hitches" report: the work is not caused by the
    /// crossing, it is simply always running.
    /// </summary>
    private Vector2? _lastDemandCentre;

    /// <summary>How far the player must move before a rescan can find anything new.</summary>
    private const float DemandRescanDistance = 24f;
    private bool _demandStreamDoodads = true;

    // Vantages: reproducible viewpoints (FOUNDATION_PLAN / PLAN_01, step 1).
    private VantageStore? _vantages;
    private string _vantageNameInput = "";
    private bool _reloadVantageKeyDown;
    private bool _dumpKeyDown;
    private string? _currentVantage;

    // Curated visibility overrides: core data, loaded and honoured always (even in
    // a release build); the click-to-author UI is dev-only. See PLAN_04.
    private VisibilityOverrides? _overrides;

    private bool _disposed;

    // A player can stand half a tile diagonal from its centre. Keeping objects
    // for that reach plus draw distance and a small large-model margin means a
    // tile transition never reveals an object that was not resident already.
    private float ObjectResidencyRadius
        => (_doodads?.DrawDistance ?? _config.Render.DoodadDistance)
         + TerrainRenderer.GridSize * 0.7071068f + 50f;

    // Models outside this radius are not parsed, decoded or uploaded. The
    // small lead hides normal walking latency without turning a discovered WMO
    // into a request for every piece of furniture it contains.
    private float DoodadDemandRadius
        => MathF.Min(_atmosphere.VisibilityDistance,
            (_doodads?.DrawDistance ?? _config.Render.DoodadDistance) + 100f);

    private int WmoPreloadRadius
        => Math.Max(_config.Start.TileRadius + 1, _config.Start.WmoPreloadRadius);

    // Collision is built from the already-loaded client geometry (WMO + doodads)
    // unless the config points at server vmaps. Only in this mode do streamed-in
    // doodads need to trigger a collision rebuild (vmap collision is per-tile).
    private bool ClientGeometryCollision
        => _config.Movement.Collision
         && !string.Equals(_config.Movement.CollisionSource, "vmaps",
                StringComparison.OrdinalIgnoreCase)
         && _wmo is not null;

    public GameLoop(ClientWindow window, ClientConfig config)
    {
        _window = window;
        _config = config;
        _atmosphere.FogEnd = Math.Clamp(config.Render.WmoDistance, 100f, config.Render.FarPlane);
        _atmosphere.FogStart = MathF.Min(350f, _atmosphere.FogEnd - 1f);
    }

    public void Load(GL gl)
    {
        var startup = Stopwatch.StartNew();

        _window.Camera.Target = new Vector3(_config.Start.X, _config.Start.Y, _config.Start.Z);
        _window.Camera.Yaw = _config.Start.Orientation;

        // Mount the archives once and point AdtTerrainReader's extractor hook at
        // them. Without this every file read reopens up to fifteen MPQs.
        _mpq = new MpqMount(_config.ClientDataPath);
        AdtTerrainReader.StormLibExtractor = _mpq.ReadFile;

        _uploads = _window.CreateGpuUploadWorker();
        _assetWorkers = new AssetWorkerPool();
        _gpuProfiler = new GpuFrameProfiler(gl);
        Console.WriteLine("[stream] dedicated shared-context GPU uploader ready");

        _terrain = new TerrainRenderer(gl, _config, _uploads, _assetWorkers);

        // Shaders are copied next to the exe by the csproj; fall back to the
        // source tree so editing a .frag and hitting F5 picks it up.
        var shaderDir = Path.Combine(AppContext.BaseDirectory, "Shaders");
        if (!File.Exists(Path.Combine(shaderDir, "terrain.vert")))
            shaderDir = Path.Combine(_config.RepoRoot, "MSUIClient", "Shaders");
        _terrain.LoadShaders(shaderDir);

        // One parse per tile, shared by terrain, buildings and doodads.
        _adts = new AdtCache(_config.ClientDataPath, _config.Start.MapName);
        if (_config.DevTools) _vantages = VantageStore.Load(_config.RepoRoot);
        InitHitchRecorder();

        _residentCentre = TerrainRenderer.TileAt(_config.Start.X, _config.Start.Y);

        // Every renderer below is created EMPTY here (cheap: shader compile + GL
        // objects) and filled incrementally by the world loader (Program.Loading.cs)
        // across the following frames, behind the loading screen. The multi-second
        // work - terrain tiles, building models, the collision BVH - is NO LONGER
        // done in this callback, so the render loop starts and presents the loading
        // curtain immediately instead of freezing on a frozen window.
        try
        {
            _wmo = new WmoRenderer(gl, _config, _uploads, _assetWorkers);
            _wmo.LoadShaders(shaderDir);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[wmo] FAILED - {ex.Message}");
            _wmo = null;
        }

        // Curated visibility overrides are core: loaded and honoured regardless of
        // DevTools, so a shipped build gets the hand-authored fixes.
        _overrides = VisibilityOverrides.Load(_config.RepoRoot);
        if (_wmo is not null) _wmo.Overrides = _overrides;

        _liquid = new LiquidRenderer(gl);
        _liquid.LoadShaders(shaderDir);
        _liquid.LoadLiquidTextures(_config.ClientDataPath);

        _sky = new SkyRenderer(gl);
        _sky.LoadShaders(shaderDir);

        _foliage = new FoliageRenderer(gl, _config);
        _foliage.LoadShaders(shaderDir);
        _foliage.LoadDbcs();

        try
        {
            _particles = new ParticleRenderer(gl, _config);
            _particles.DensityScale = _config.Render.ParticleDensity;
            _particles.LoadShaders(shaderDir);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[particles] FAILED - {ex.Message}");
            _particles = null;
        }

        // FFXGlow whole-scene bloom (Engine/FfxGlow.cs). Faithful benilla glow,
        // composited additively so the exterior base lighting is untouched - only
        // highlight bloom is added. render.glowGain is the per-zone weight;
        // render.glow = false disables the pass entirely.
        try
        {
            _glow = _config.Render.Glow
                ? new FfxGlow(gl) { Gain = _config.Render.GlowGain }
                : null;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[glow] FAILED - {ex.Message}");
            _glow = null;
        }

        // Exterior lighting's authored data (PLAN_09). Applied every frame by
        // UpdateExteriorLighting once loading is done.
        InitLightProbe();

        if (_config.Render.Doodads)
        {
            try
            {
                _doodads = new DoodadRenderer(gl, _config, _uploads, _assetWorkers)
                {
                    DrawDistance = _config.Render.DoodadDistance,
                    CollisionBasisIndex = _config.Render.DoodadCollisionBasis,
                    // Always demand-stream now: the loader queues the near models
                    // and they arrive through the normal streaming path, faded in.
                    DemandStreaming = true,
                };
                _doodads.LoadShaders(shaderDir);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[doodad] FAILED - {ex.Message}");
                _doodads = null;
            }
        }

        _mpq?.Report();

        // The controller exists now so Update/Render run and the loader can drive
        // the build across frames. Collision is null until the loader's off-thread
        // BVH lands; the ground snap happens in the loader once terrain is resident.
        _controller = new CharacterController(_terrain, _config.Movement)
        {
            Collision = null,
            Yaw = _config.Start.Orientation,
        };
        _controller.Teleport(_config.Start.X, _config.Start.Y, _config.Start.Z);
        _window.Camera.Target = _controller.Position;

        // The character model. Independent of the world build, so it stays in the
        // fast shell setup.
        try
        {
            _character = new CharacterRenderer(gl, _config);
            _character.LoadShaders(shaderDir);

            if (!_character.Load("Human", "Male"))
            {
                _character.Dispose();
                _character = null;
            }
            else
            {
                _character.Equipment = CharacterEquipment.BattlegearOfMight();
                _character.ApplyEquipment();
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[character] FAILED - {ex.Message}");
            _character = null;
        }

        try
        {
            _collisionDebug = new CollisionDebugRenderer(gl);
            _collisionDebug.LoadShaders(shaderDir);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[collision] debug renderer FAILED - {ex.Message}");
            _collisionDebug = null;
        }

        // The settings modal's skin needs GL and the MPQ mount, so it is built
        // last; applying the saved settings needs every renderer to exist.
        InitSettings(gl);

        Console.WriteLine($"[startup] shell ready in {startup.Elapsed.TotalSeconds:F2}s - " +
                          "streaming the world in behind the loading screen");

        // Hand off to the budgeted, per-frame world loader (Program.Loading.cs).
        // It queues the terrain/WMO streaming, then StepWorldLoad advances it a
        // bounded slice per frame while DrawLoadingScreen covers it.
        // Phase 2: create the network client, then start the world load ONLY when offline.
        // Networked mode stays stateless (no world, no character) until SMSG_LOGIN_VERIFY_WORLD
        // assigns a spawn point; PumpNet then sets _config.Start and calls BeginWorldLoad.
        InitNet(gl);
        if (!_config.Server.Enabled)
            BeginWorldLoad(gl);
    }

    private void PopulateDoodads((int col, int row) centreTile, bool reportDiagnostics)
    {
        if (_doodads is null || _terrain is null || _adts is null) return;

        Vector2 centre = TerrainRenderer.TileCenter(centreTile.col, centreTile.row);
        float radius = ObjectResidencyRadius;

        // Two very different jobs share this method's cost: walking nine ADTs'
        // MDDF lists, and enumerating every MODD placement of every resident
        // WMO. At 7,562 placements this measured 71 ms and we do not yet know
        // which half. Split before optimizing - that has been right every time.
        long doodadPhase = Stopwatch.GetTimestamp();
        _doodads.LoadForTiles(
            _terrain.LoadedTiles, _adts, centre, radius, reportDiagnostics);
        _outdoorPlacementMilliseconds = Stopwatch.GetElapsedTime(doodadPhase).TotalMilliseconds;

        // Furniture. A huge WMO can touch the terrain ring while most of its
        // MODD placements are far outside doodad draw range. Resolve only the
        // furniture that could become visible before the next tile crossing.
        if (_wmo is null) return;

        var interiors = Stopwatch.StartNew();
        int requested = 0, placed = 0;
        foreach (var (path, transform, light) in _wmo.EnumerateDoodads(centre, radius))
        {
            requested++;
            if (_doodads.AddPlaced(path, transform, light)) placed++;
        }
        _interiorPlacementMilliseconds = interiors.Elapsed.TotalMilliseconds;
        _placementsRequested = requested;

        if (reportDiagnostics && requested > 0)
            _doodads.ReportInterior(requested, placed, interiors.Elapsed.TotalSeconds);

        if (reportDiagnostics)
            Console.WriteLine($"[stream] object residency [{centreTile.col},{centreTile.row}] " +
                              $"radius {radius:F0} yd");
    }

    private void UpdateWorldResidency()
    {
        if (_controller is null || _terrain is null || _adts is null) return;

        var next = TerrainRenderer.TileAt(_controller.Position.X, _controller.Position.Y);
        if (_residentCentre == next) return;

        // The timer starts HERE, not after the readiness gate. It used to start
        // below and reported 0.06s for a crossing the hitch recorder measured at
        // 0.17s - a phase timer that starts late lies quietly (handbook 8.7).
        var timer = Stopwatch.StartNew();

        var terrainLead = TerrainRenderer.TileRing(
            next.col, next.row, _config.Start.TileRadius + 1);
        _terrain.QueuePreload(terrainLead, _adts);
        var desiredTerrain = TerrainRenderer.TileRing(
            next.col, next.row, _config.Start.TileRadius);
        if (!_terrain.PreloadReady(desiredTerrain)) return;

        double gateSeconds = timer.Elapsed.TotalSeconds;
        Console.WriteLine($"[stream] crossing to tile [{next.col},{next.row}]");

        try
        {
            // Sub-phase timing. The crossing is one synchronous block that
            // rebuilds every placement in the resident ring from scratch, and
            // NO amount of waiting before the boundary avoids it - that is
            // Nico's observation and it rules out "the async work had not
            // finished" as the explanation. So the question is only WHICH
            // rebuild dominates, and that is a measurement, not a theory.
            long t0 = Stopwatch.GetTimestamp();
            _terrain.SetResidency(next.col, next.row, _config.Start.TileRadius, _adts);
            double terrainMs = Stopwatch.GetElapsedTime(t0).TotalMilliseconds;

            t0 = Stopwatch.GetTimestamp();
            _wmo?.ResetPlacements();
            _wmo?.LoadForTiles(_terrain.LoadedTiles, _adts);
            double wmoMs = Stopwatch.GetElapsedTime(t0).TotalMilliseconds;

            t0 = Stopwatch.GetTimestamp();
            _liquid?.LoadForTiles(_terrain.LoadedTiles, _adts);
            double liquidMs = Stopwatch.GetElapsedTime(t0).TotalMilliseconds;

            var preloadRing = TerrainRenderer.TileRing(next.col, next.row, WmoPreloadRadius);

            t0 = Stopwatch.GetTimestamp();
            _wmo?.QueuePreloadForTiles(preloadRing, _adts);
            double wmoQueueMs = Stopwatch.GetElapsedTime(t0).TotalMilliseconds;

            t0 = Stopwatch.GetTimestamp();
            _doodads?.ResetPlacements();
            PopulateDoodads(next, reportDiagnostics: false);
            double doodadMs = Stopwatch.GetElapsedTime(t0).TotalMilliseconds;

            t0 = Stopwatch.GetTimestamp();
            _adts.Retain(preloadRing);
            double retainMs = Stopwatch.GetElapsedTime(t0).TotalMilliseconds;

            _residentCentre = next;

            t0 = Stopwatch.GetTimestamp();
            BeginCollisionBuild();
            double collisionMs = Stopwatch.GetElapsedTime(t0).TotalMilliseconds;

            _lastStreamSeconds = timer.Elapsed.TotalSeconds;
            Console.WriteLine($"[stream] tile [{next.col},{next.row}] ready: " +
                              $"{_terrain.TileCount} terrain, {_wmo?.InstanceCount ?? 0} WMO, " +
                              $"{_doodads?.InstanceCount ?? 0} doodad placement(s), " +
                              $"{_lastStreamSeconds:F2}s (queue/gate {gateSeconds:F2}s)");
            Console.WriteLine($"[stream]   terrain {terrainMs:F1} ms  wmo {wmoMs:F1}  " +
                              $"liquid {liquidMs:F1}  wmoQueue {wmoQueueMs:F1}  " +
                              $"doodads {doodadMs:F1}  retain {retainMs:F1}  " +
                              $"collisionSnapshot {collisionMs:F1}  " +
                              $"(ring deferred {_wmo?.DeferredRingTiles ?? 0})");
            Console.WriteLine($"[stream]   doodads {doodadMs:F1} = outdoor " +
                              $"{_outdoorPlacementMilliseconds:F1} + wmoInterior " +
                              $"{_interiorPlacementMilliseconds:F1} over " +
                              $"{_placementsRequested:N0} MODD placement(s); " +
                              $"residency radius {ObjectResidencyRadius:F0} yd, " +
                              $"draw {_doodads?.DrawDistance ?? 0:F0} yd");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[stream] FAILED entering [{next.col},{next.row}]: {ex.Message}");
        }
    }

    private void SetCollisionDebugEnabled(bool enabled)
    {
        if (_collisionDebug is null) return;

        if (enabled && _collisionDebug.TriangleCount == 0 && _collision is not null)
        {
            var timer = Stopwatch.StartNew();
            _collisionDebug.Build(_collision);
            Console.WriteLine($"[collision] debug upload deferred from startup: " +
                              $"{timer.Elapsed.TotalSeconds:F2}s");
        }

        _collisionDebug.Enabled = enabled;
    }

    /// <summary>
    /// Cross-check the rendered buildings against the collision meshes of the
    /// same buildings.
    ///
    /// These arrive by two completely independent routes — MODF placements read
    /// out of the ADT and transformed here, versus vmtile spawns extracted by
    /// the server and transformed by the collision loader. They describe the
    /// same objects, so any disagreement means one transform is wrong, and the
    /// SHAPE of the disagreement says which.
    ///
    /// A constant offset across every building points at a systematic error in
    /// one of the two placement chains — fixable in one line. Deltas that vary
    /// per building, especially with rotation, point at the rotation
    /// convention instead. Either way this turns "collision feels a few yards
    /// off" into a vector.
    /// </summary>
    /// <summary>
    /// Draw, in yellow and over everything, the exact triangles the character
    /// controller is standing on and blocked by — pulled by index from the same
    /// array the raycast intersected.
    ///
    /// The bulk wireframe answers "where is the collision world". This answers
    /// "where is the surface I am actually standing on", which is the only
    /// question that matters when movement disagrees with the picture.
    /// </summary>
    private void HighlightPhysicsTriangles()
    {
        if (_collisionDebug is null || _collision is null || _controller is null) return;
        if (!_collisionDebug.Enabled) return;

        var corners = new List<Vector3>(6);

        if (_collision.TryGetTriangle(_controller.GroundTriangle, out var a, out var b, out var c))
        {
            corners.Add(a); corners.Add(b); corners.Add(c);
        }

        if (_controller.HasBlock &&
            _collision.TryGetTriangle(_controller.LastBlockTriangle, out var d, out var e, out var f))
        {
            corners.Add(d); corners.Add(e); corners.Add(f);
        }

        if (corners.Count >= 3) _collisionDebug.RenderHighlight(_window.Camera, corners);
    }

    private void CompareWmoToCollision()
    {
        if (_wmo is null || _vmaps is null || _vmaps.WmoSpawnBounds.Count == 0) return;

        var deltas = new List<Vector3>();
        var originDeltas = new List<Vector3>();

        foreach (var (path, rMin, rMax, rOrigin) in _wmo.Placements)
        {
            string name = Path.GetFileName(path);
            var renderCentre = (rMin + rMax) * 0.5f;

            // Match by model name, then by proximity — a model placed several
            // times needs the nearest instance, not the first one.
            (string Name, Vector3 Min, Vector3 Max, Vector3 Origin)? best = null;
            float bestDistance = float.MaxValue;

            foreach (var spawn in _vmaps.WmoSpawnBounds)
            {
                if (!string.Equals(Path.GetFileName(spawn.Name), name, StringComparison.OrdinalIgnoreCase))
                    continue;

                float d = (((spawn.Min + spawn.Max) * 0.5f) - renderCentre).Length();
                if (d >= bestDistance) continue;

                bestDistance = d;
                best = spawn;
            }

            if (best is null) continue;

            var collisionCentre = (best.Value.Min + best.Value.Max) * 0.5f;
            var delta = collisionCentre - renderCentre;
            deltas.Add(delta);

            // ORIGIN vs ORIGIN. Bounding boxes depend on which triangles each
            // extractor kept, so they can never separate "the mesh is
            // different" from "the placement is different". The origins are
            // pure placement: the same building's MODF entry and its vmtile
            // spawn describe one position, so any difference here is a
            // transform bug and nothing else.
            var originDelta = best.Value.Origin - rOrigin;
            if (originDelta.Length() > 0.05f)
                Console.WriteLine(
                    $"[align] {name,-28} ORIGIN differs by ({originDelta.X,7:F2}," +
                    $"{originDelta.Y,7:F2},{originDelta.Z,7:F2}) = {originDelta.Length():F2} yd");
            originDeltas.Add(originDelta);

            if (delta.Length() > 1.5f)
            {
                // Size as well as centre. If the two footprints are the same
                // size but offset, the error is a translation. If the sizes
                // differ, the geometry is rotated differently and no amount of
                // shifting will line them up.
                var renderSize = rMax - rMin;
                var collisionSize = best.Value.Max - best.Value.Min;
                var sizeDelta = collisionSize - renderSize;

                Console.WriteLine(
                    $"[align] {name,-28} centre ({delta.X,7:F2},{delta.Y,7:F2},{delta.Z,7:F2}) " +
                    $"{delta.Length(),6:F2} yd   size ({sizeDelta.X,7:F2},{sizeDelta.Y,7:F2},{sizeDelta.Z,7:F2})");
            }
        }

        if (deltas.Count == 0)
        {
            Console.WriteLine("[align] no buildings matched between render and collision");
            return;
        }

        var mean = deltas.Aggregate(Vector3.Zero, (a, d) => a + d) / deltas.Count;
        double spread = deltas.Average(d => (double)(d - mean).Length());

        Console.WriteLine(
            $"[align] {deltas.Count} building(s) compared: mean offset " +
            $"({mean.X:F2}, {mean.Y:F2}, {mean.Z:F2}), magnitude {mean.Length():F2} yd, " +
            $"spread {spread:F2} yd");

        Console.WriteLine(spread < 1.0
            ? "[align] centre offset is consistent across buildings"
            : "[align] centre offset varies - expected, since the two meshes are not the same triangles");

        if (originDeltas.Count > 0)
        {
            var originMean = originDeltas.Aggregate(Vector3.Zero, (a, d) => a + d) / originDeltas.Count;
            float worst = originDeltas.Max(d => d.Length());

            Console.WriteLine(
                $"[align] ORIGINS: mean ({originMean.X:F3}, {originMean.Y:F3}, {originMean.Z:F3}), " +
                $"worst {worst:F3} yd");

            Console.WriteLine(worst < 0.05f
                ? "[align] origins AGREE - both chains place buildings at the same point, so any "
                  + "remaining misalignment is ROTATION or the mesh itself"
                : "[align] origins DISAGREE - one chain's translation is wrong, and that is the bug");
        }
    }

    /// <summary>
    /// Load vmap collision for exactly the tiles terrain loaded. Every failure
    /// here is non-fatal and printed: without vmaps you still walk on terrain,
    /// you just walk through buildings.
    /// </summary>
    private void LoadCollision()
    {
        if (_terrain is null) return;

        _collision = null;
        _vmaps = null;
        if (_controller is not null) _controller.Collision = null;
        _collisionDebug?.Clear();

        if (!_config.Movement.Collision)
        {
            Console.WriteLine("[collision] disabled in config (movement.collision = false)");
            return;
        }

        bool useClient = !string.Equals(_config.Movement.CollisionSource, "vmaps",
            StringComparison.OrdinalIgnoreCase);

        if (!useClient && !_config.HasVmaps)
        {
            Console.WriteLine("[collision] collisionSource is vmaps but none are configured — terrain only");
            return;
        }

        var started = DateTime.UtcNow;

        try
        {
            _collision = new CollisionWorld();

            if (useClient)
            {
                // The buildings the renderer already loaded. No second parse,
                // no second transform, no GameData\vmaps needed.
                if (_wmo is null)
                {
                    Console.WriteLine("[collision] no buildings loaded — terrain only");
                    _collision = null;
                    return;
                }

                _wmo.AppendCollision(_collision);
                _doodads?.AppendCollision(_collision);
            }
            else
            {
                _vmaps = new VmapCollisionLoader(_config.VmapPath!);

                foreach (var (col, row) in _terrain.LoadedTiles)
                    _vmaps.LoadTile(_collision, _config.Start.Map, col, row, _config.Movement.IncludeM2);
            }

            _collision.Build();
            _collisionBuildSeconds = (DateTime.UtcNow - started).TotalSeconds;

            if (_vmaps is not null) Console.WriteLine($"[collision] {_vmaps.Summary()}");
            Console.WriteLine(
                $"[collision] BVH {_collision.NodeCount:N0} nodes over " +
                $"{_collision.TriangleCount:N0} triangles, " +
                $"{_collision.DegenerateSkipped} degenerate skipped, " +
                $"{_collisionBuildSeconds:F1}s");

            // Bounds are the cheapest possible check that the spawn transform is
            // right: if this box does not straddle the loaded tiles, the geometry
            // is real but in the wrong place, and no amount of walking into
            // things will reveal that.
            var lo = _collision.BoundsMin;
            var hi = _collision.BoundsMax;
            Console.WriteLine(
                $"[collision] bounds X {lo.X:F0}..{hi.X:F0}  Y {lo.Y:F0}..{hi.Y:F0}  Z {lo.Z:F0}..{hi.Z:F0}");

            if (_collision.IsEmpty)
            {
                Console.WriteLine("[collision] WARNING no geometry loaded — check the unresolved names above");
                _collision = null;
            }

            if (_controller is not null) _controller.Collision = _collision;
            if (_collisionDebug is { Enabled: true } && _collision is not null)
                _collisionDebug.Build(_collision);
        }
        catch (Exception ex)
        {
            // Loudly. A silent failure here would present later as a physics bug.
            Console.WriteLine($"[collision] FAILED — {ex.Message}");
            Console.WriteLine("[collision] continuing with terrain collision only");
            _collision = null;
        }
    }

    /// <summary>
    /// Rebuild client-geometry collision without stopping movement. Triangle
    /// collection is a bounded snapshot on the render thread; the expensive
    /// BVH partition/sort runs on a worker while the previous world remains
    /// attached to the controller.
    /// </summary>
    private void BeginCollisionBuild()
    {
        bool useClient = !string.Equals(_config.Movement.CollisionSource, "vmaps",
            StringComparison.OrdinalIgnoreCase);
        if (!_config.Movement.Collision || !useClient || _wmo is null)
        {
            LoadCollision();
            return;
        }

        // Snapshot ONLY the placement list here: a reference to each model's
        // immutable triangle array plus its transform. A few thousand tiny
        // structs, sub-millisecond.
        //
        // What used to be here was the full expansion - ~509,000 triangles,
        // three Vector3.Transform calls each - measured by the hitch recorder
        // at 92.9 ms and fired on a timer every few seconds while doodads
        // streamed, to add a handful of props. Nothing on screen changed
        // because nothing on screen HAD changed; the work was re-deriving
        // geometry it already had.
        //
        // Handbook 5.4 forbids a worker reading live renderer placement
        // collections while they mutate. That applies to the LIST, which is
        // copied here, not to model geometry, which is immutable once loaded -
        // so the expansion belongs with the BVH build on the worker.
        var batches = new List<CollisionBatch>(8192);
        int buildings = _wmo.SnapshotCollision(batches);
        int props = _doodads?.SnapshotCollision(batches) ?? 0;
        _collisionDebug?.Clear();

        int generation = ++_collisionGeneration;
        _collisionBuildTask = Task.Run(() =>
        {
            var timer = Stopwatch.StartNew();
            var next = new CollisionWorld();

            int triangles = 0, skipped = 0;
            foreach (var batch in batches)
            {
                var tris = batch.Triangles;
                int source = next.RegisterSource(Path.GetFileName(batch.Path));
                var m = batch.Transform;

                for (int i = 0; i + 2 < tris.Length; i += 3)
                {
                    next.AddTriangle(
                        Vector3.Transform(tris[i], m),
                        Vector3.Transform(tris[i + 1], m),
                        Vector3.Transform(tris[i + 2], m),
                        source);
                    triangles++;
                }

                skipped += batch.Skipped;
            }

            double expandSeconds = timer.Elapsed.TotalSeconds;
            next.Build();

            Console.WriteLine(
                $"[collision] {buildings} building(s) + {props} doodad(s), " +
                $"{triangles:N0} triangles expanded in {expandSeconds * 1000:F0}ms " +
                $"off-thread ({skipped:N0} detail excluded)");

            return (generation, next, timer.Elapsed.TotalSeconds);
        });
    }

    private void AcceptReadyCollision()
    {
        if (_collisionBuildTask is not { IsCompleted: true } task) return;
        _collisionBuildTask = null;

        try
        {
            var ready = task.GetAwaiter().GetResult();
            if (ready.Generation != _collisionGeneration) return;

            _collision = ready.World.IsEmpty ? null : ready.World;
            _collisionBuildSeconds = ready.Seconds;
            if (_controller is not null) _controller.Collision = _collision;

            Console.WriteLine(
                $"[collision-async] BVH {ready.World.NodeCount:N0} nodes over " +
                $"{ready.World.TriangleCount:N0} triangles, {ready.Seconds:F2}s off-thread");

            if (_collision is not null)
            {
                var lo = _collision.BoundsMin;
                var hi = _collision.BoundsMax;
                Console.WriteLine(
                    $"[collision-async] bounds X {lo.X:F0}..{hi.X:F0}  " +
                    $"Y {lo.Y:F0}..{hi.Y:F0}  Z {lo.Z:F0}..{hi.Z:F0}");
                if (_collisionDebug is { Enabled: true }) _collisionDebug.Build(_collision);
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[collision-async] FAILED - {ex.Message}; keeping previous collision");
        }
    }

    public void Update(float dt)
    {
        // Frame boundary. Update-entry to Update-entry is the only placement
        // where a frame's Update AND its Render both fall inside the period
        // being measured - see HitchRecorder.FrameBoundary for why the obvious
        // alternative silently blames the wrong frame.
        if (_hitch.FrameBoundary(CurrentFramePhases())) WriteHitchRecord();

        // Quitting is deferred out of the GUI pass and lands HERE, between
        // frames, before anything is touched. ClientWindow.Close tears the GL
        // context down synchronously - it raises Closing, which runs
        // GameLoop.Dispose and deletes every texture and buffer we own - so
        // calling it from inside a button handler left the rest of that ImGui
        // frame drawing into freed memory. That is an AccessViolationException on
        // the next widget, and the stack points at the widget rather than at the
        // button, which is what makes it worth a comment.
        if (ConsumeQuitRequest()) return;

        long updateStarted = Stopwatch.GetTimestamp();
        if (_controller is null) return;

        // Advance the appear-fade clock every frame - during the loading build and
        // after - so streamed-in doodads/buildings ease in instead of popping.
        UpdateAppearFadeClock(dt);

        // Benilla-style: while the loading curtain is up, drive the budgeted
        // world build and skip gameplay (movement/residency) for this frame.
        if (_worldLoading) { StepWorldLoad(dt); return; }

        PumpNet(dt); // Phase 2 networking pump (no-op unless server.enabled)

        // Networked: stay stateless (no world/character) until login assigns a spawn point.
        if (_config.Server.Enabled && !_worldLoadStarted) return;

        // Adopting ready terrain creates VAOs and installs height grids on this
        // thread; five tiles can land in one frame.
        long headStarted = Stopwatch.GetTimestamp();
        _terrain?.PumpPreloads();
        _pumpPreloadsMilliseconds = Stopwatch.GetElapsedTime(headStarted).TotalMilliseconds;

        headStarted = Stopwatch.GetTimestamp();
        AcceptReadyCollision();
        _acceptCollisionMilliseconds = Stopwatch.GetElapsedTime(headStarted).TotalMilliseconds;

        _doodadCollisionSnapshotMilliseconds = 0;

        // Fold newly-streamed doodads into the collision world once a build slot
        // is free. Coalesced (one build at a time, at most ~1/s) so a burst of
        // streaming near a busy tile doesn't rebuild the BVH every frame. This is
        // what keeps trees/fences solid in demand-stream mode; the world settles
        // to include all resident doodads within ~a second of them appearing.
        _doodadCollisionRebuildCooldown -= dt;
        if (_doodadCollisionDirty) _doodadCollisionDeferredFor += dt;

        // Two gates, not one. The cooldown limits how OFTEN; the delta limits
        // whether it is worth doing at all. A rebuild costs a full ~509,000
        // triangle re-expansion plus a from-scratch BVH, so firing it because
        // ten props arrived re-derives the entire world to add a rounding
        // error. The defer timer is the safety valve: a slow trickle still
        // becomes solid, just later.
        // Rebuild when streaming has SETTLED, not while it is in flight. Each
        // rebuild is a ~500,000 triangle expansion plus a from-scratch BVH -
        // 0.6 to 1.1 s of worker time - and firing one every couple of seconds
        // during a stream-in kept a core pegged and the memory bus busy
        // continuously. On an integrated GPU sharing that bus with the render
        // thread, that is not free even though it is "off the main thread":
        // the present-swap stalls in the same logs are what it looks like.
        bool streamingSettled = (_doodads?.PendingPreloads ?? 0) == 0;
        bool worthRebuilding =
            (streamingSettled && _doodadCollisionPending > 0) ||
            _doodadCollisionDeferredFor >= DoodadCollisionMaxDeferSeconds;

        if (_doodadCollisionDirty && _collisionBuildTask is null
            && _doodadCollisionRebuildCooldown <= 0f && worthRebuilding)
        {
            _doodadCollisionDirty = false;
            _doodadCollisionPending = 0;
            _doodadCollisionDeferredFor = 0f;
            // 1.0s meant a full ~1.17M-triangle main-thread re-walk EVERY SECOND
            // while doodads streamed in - visible as the repeated
            // "[collision] from client geometry" spam in every log. Until the
            // snapshot is per-tile and spliced (PLAN_08 D3), coalescing harder
            // is the cheap win: trees become solid a couple of seconds later,
            // which no one can perceive, and the stutter happens a third as often.
            _doodadCollisionRebuildCooldown = 3.0f;

            // NOT free, and until now not measured: this is the same ~500k
            // triangle main-thread walk the crossing pays, fired on a timer
            // while doodads stream. Timed separately from the crossing's copy
            // (which is inside residency) so neither is double-counted.
            long snapshotStarted = Stopwatch.GetTimestamp();
            BeginCollisionBuild();
            _doodadCollisionSnapshotMilliseconds =
                Stopwatch.GetElapsedTime(snapshotStarted).TotalMilliseconds;
        }

        if (_cycleTimeOfDay)
            _atmosphere.TimeOfDayHours += dt * _gameHoursPerMinute / 60f;

        // Resolve what Light.dbc says here, now, and APPLY it. This is core and
        // runs in every build - the comment that used to sit here said "Read-only:
        // it feeds the probe panel and nothing else", which was false, and is how
        // the DevTools seam violation survived several readings. In Update rather
        // than Render so the render pass stays free of work that is not drawing.
        UpdateExteriorLighting();

        // Which WMO group the camera stands in (PLAN_10 D1). Read-only for now:
        // the HUD shows it, nothing culls on it yet. Cheap - a world-box reject
        // per instance before any matrix is inverted.
        _wmo?.UpdateCameraCell(_window.Camera.Position);

        // Escape. It used to close the client outright; it now opens the game
        // menu, and quitting is a button inside it. See Program.Settings.cs.
        UpdateSettingsInput();

        // Ignore keyboard input while ImGui owns the keyboard (typing in a text
        // field such as the vantage name), so it does not turn/strafe/jump the
        // player - and equally while the settings modal is up, or you walk into a
        // lake while dragging a slider.
        bool typing = ImGui.GetIO().WantCaptureKeyboard || _settingsOpen;

        // F toggles free-fly. Edge-triggered so holding it doesn't strobe.
        bool flyKey = _window.IsDown(Key.F);
        if (flyKey && !_flyKeyDown && !typing)
        {
            _controller.Flying = !_controller.Flying;
            Console.WriteLine($"[move] {(_controller.Flying ? "flying" : "walking")}");
        }
        _flyKeyDown = flyKey;

        // C toggles the collision wireframe. Edge-triggered.
        bool collisionKey = _window.IsDown(Key.C);
        if (collisionKey && !_collisionKeyDown && _collisionDebug is not null && _config.DevTools && !typing)
        {
            SetCollisionDebugEnabled(!_collisionDebug.Enabled);
            Console.WriteLine($"[collision] wireframe {(_collisionDebug.Enabled ? "on" : "off")}");
        }
        _collisionKeyDown = collisionKey;

        // Middle-click identifies the WMO group(s) under the cursor. Edge-triggered,
        // and skipped when the pointer is over the HUD.
        bool pickButton = _window.MouseMiddleDown;
        if (pickButton && !_pickButtonDown && !ImGui.GetIO().WantCaptureMouse && _config.DevTools)
            ScreenPick(_window.MousePosition);
        _pickButtonDown = pickButton;

        // F8 reloads the current vantage - snap back to the saved viewpoint.
        // Edge-triggered so holding it does not re-teleport every frame.
        bool reloadKey = _window.IsDown(Key.F8);
        if (reloadKey && !_reloadVantageKeyDown && _currentVantage is not null && _vantages is not null && _config.DevTools)
        {
            var saved = _vantages.Find(_currentVantage);
            if (saved is not null) ApplyVantage(saved);
        }
        _reloadVantageKeyDown = reloadKey;

        // F9 writes a scene dump (dev only). Edge-triggered.
        bool dumpKey = _window.IsDown(Key.F9);
        if (dumpKey && !_dumpKeyDown && _config.DevTools)
            DumpScene();
        _dumpKeyDown = dumpKey;

        bool shift = _window.IsDown(Key.ShiftLeft) || _window.IsDown(Key.ShiftRight);

        // A and D TURN, they do not strafe. That is vanilla's default bind and
        // it is what the hands expect; strafe lives on Q and E.
        //
        // Camera yaw IS the character's facing here - the controller takes
        // input.Yaw straight from it - so turning the camera turns the
        // character. There is only one heading in this client and this is it.
        //
        // Holding the RIGHT mouse button swaps the two, exactly as the real
        // client does: you are already steering with the mouse, so A and D are
        // free to become strafe and your hand does not have to move to Q and E
        // mid-fight.
        bool mouseSteering = _window.MouseRightDown;

        float turn = typing ? 0f : _window.Axis(Key.Left, Key.Right);
        if (!typing && !mouseSteering) turn += _window.Axis(Key.A, Key.D);
        turn = Math.Clamp(turn, -1f, 1f);

        if (turn != 0f) _window.Camera.Rotate(turn * _turnSpeed * dt, 0f);

        float strafe = typing ? 0f : _window.Axis(Key.E, Key.Q);
        if (!typing && mouseSteering) strafe += _window.Axis(Key.D, Key.A);
        strafe = Math.Clamp(strafe, -1f, 1f);

        // Look up and down without the mouse. Rotate clamps pitch either way.
        float tilt = typing ? 0f : _window.Axis(Key.PageUp, Key.PageDown);
        if (tilt != 0f) _window.Camera.Rotate(0f, tilt * _turnSpeed * 0.6f * dt);

        // Up and down arrows walk, like vanilla. Combined with W/S rather than
        // replacing it, and clamped so holding both does not double the speed.
        float forward = typing ? 0f : Math.Clamp(
            _window.Axis(Key.W, Key.S) + _window.Axis(Key.Up, Key.Down), -1f, 1f);

        var input = new MovementInput
        {
            Forward = forward,
            Strafe = strafe,
            Up = typing ? 0f : _window.Axis(Key.Space, Key.ControlLeft),
            Yaw = _window.Camera.Yaw,
            Jump = !typing && _window.IsDown(Key.Space),
            Walking = shift && !_controller.Flying,
            Boost = shift && _controller.Flying,
        };

        long phaseStarted = Stopwatch.GetTimestamp();
        _controller.Update(dt, input);
        _movementMilliseconds = Stopwatch.GetElapsedTime(phaseStarted).TotalMilliseconds;

        phaseStarted = Stopwatch.GetTimestamp();
        UpdateWorldResidency();

        // Portals (PLAN_13 stage 2b). AFTER residency, so the volume test runs
        // against the map we are actually on rather than the one we were on
        // when the frame began.
        UpdatePortals();
        _residencyMilliseconds = Stopwatch.GetElapsedTime(phaseStarted).TotalMilliseconds;

        // WoWee gives ready assets a small main-thread integration budget.
        // Alternate priority so neither queue starves, and never begin the
        // second GL upload/build after the first has consumed this frame.
        phaseStarted = Stopwatch.GetTimestamp();
        var preloadBudget = Stopwatch.StartNew();

        long subStarted = Stopwatch.GetTimestamp();
        DiscoverNextBackgroundTile(dt);
        _discoverMilliseconds = Stopwatch.GetElapsedTime(subStarted).TotalMilliseconds;

        subStarted = Stopwatch.GetTimestamp();
        QueueVisibleDoodadDemand(dt);
        _doodadDemandMilliseconds = Stopwatch.GetElapsedTime(subStarted).TotalMilliseconds;

        // NOTE the budget only gates the SECOND warm call. A single
        // WarmNextPreload finalizes a whole model on this thread, so one heavy
        // model blows straight through it - which is precisely what WoWee's
        // resumable advanceFinalization cursor prevents (PLAN_08 D2).
        subStarted = Stopwatch.GetTimestamp();
        if (_preloadWmoFirst) _wmo?.WarmNextPreload();
        else _doodads?.WarmNextPreload();
        if (preloadBudget.Elapsed.TotalMilliseconds < 6)
        {
            if (_preloadWmoFirst) _doodads?.WarmNextPreload();
            else _wmo?.WarmNextPreload();
        }
        _warmMilliseconds = Stopwatch.GetElapsedTime(subStarted).TotalMilliseconds;
        _preloadWmoFirst = !_preloadWmoFirst;
        _preloadMilliseconds = Stopwatch.GetElapsedTime(phaseStarted).TotalMilliseconds;

        _walking = input.Walking;
        phaseStarted = Stopwatch.GetTimestamp();
        _character?.Update(dt, BuildUnitState());
        _characterUpdateMilliseconds = Stopwatch.GetElapsedTime(phaseStarted).TotalMilliseconds;

        // Moving re-centres the camera behind the character, like the real
        // client. Holding the LEFT button overrides it: you are deliberately
        // looking at yourself, and having the view fight you would be worse
        // than not having the feature.
        // Turning counts as moving here. He said "if you hit wasd it snaps you
        // back behind the character", and A and D are part of WASD.
        bool moving = MathF.Abs(input.Forward) > 0.01f
                   || MathF.Abs(input.Strafe) > 0.01f
                   || turn != 0f;

        if (moving && !_window.MouseLeftDown) _window.Camera.EaseOrbitBehind(dt);

        // The camera orbits the character's feet; Camera.EyeHeight does the rest.
        _window.Camera.Target = _controller.Position;

        phaseStarted = Stopwatch.GetTimestamp();
        ResolveCameraCollision(dt);
        _cameraCollisionMilliseconds = Stopwatch.GetElapsedTime(phaseStarted).TotalMilliseconds;

        _updateMilliseconds = Stopwatch.GetElapsedTime(updateStarted).TotalMilliseconds;
    }

    private void DiscoverNextBackgroundTile(float dt)
    {
        if (_terrain is null || _adts is null || _assetWorkers is null) return;

        if (_backgroundAdtLoad is { IsCompleted: true } completed)
        {
            try { completed.GetAwaiter().GetResult(); }
            catch (Exception ex)
            {
                Console.WriteLine($"[preload-discovery] tile [{_backgroundAdtTile.col}," +
                                  $"{_backgroundAdtTile.row}] failed - {ex.Message}");
            }

            _terrain.QueuePreload([_backgroundAdtTile], _adts);
            _wmo?.QueuePreloadForTiles([_backgroundAdtTile], _adts);
            Console.WriteLine($"[preload-discovery] tile [{_backgroundAdtTile.col}," +
                              $"{_backgroundAdtTile.row}], " +
                              $"{_backgroundDiscovery.Count} outer tile(s) remaining");
            _backgroundAdtLoad = null;
        }

        if (_backgroundAdtLoad is not null || _backgroundDiscovery.Count == 0) return;
        _backgroundDiscoveryDelay -= dt;
        if (_backgroundDiscoveryDelay > 0f) return;
        _backgroundDiscoveryDelay = 0.05f;

        _backgroundAdtTile = _backgroundDiscovery.Dequeue();
        _backgroundAdtLoad = _adts.QueueLoad(
            _backgroundAdtTile.col, _backgroundAdtTile.row, _assetWorkers);
    }

    private void QueueVisibleDoodadDemand(float dt)
    {
        if (!_demandStreamDoodads || _doodads is null || _terrain is null ||
            _adts is null || _controller is null || _residentCentre is null) return;

        _doodadDemandDelay -= dt;
        if (_doodadDemandDelay > 0f) return;
        _doodadDemandDelay = 0.25f;

        var centre = new Vector2(_controller.Position.X, _controller.Position.Y);

        // Nothing can have changed if no model is still in flight to acquire
        // placements AND the player has not moved far enough to bring anything
        // new into range. Skipping is not an optimization here - running was
        // the bug. Back the interval off while idle so a stationary player
        // costs nothing at all.
        bool streamingInFlight = _doodads.PendingPreloads > 0;
        if (!streamingInFlight && _lastDemandCentre is { } last &&
            Vector2.DistanceSquared(centre, last) < DemandRescanDistance * DemandRescanDistance)
        {
            _doodadDemandDelay = 1.0f;
            return;
        }

        _lastDemandCentre = centre;
        float radius = DoodadDemandRadius;
        _doodads.QueuePreloadForTiles(_terrain.LoadedTiles, _adts, centre, radius);
        if (_wmo is not null)
            _doodads.QueuePreloadModels(
                _wmo.EnumerateDoodads(centre, radius)
                    .OrderBy(d => Vector2.DistanceSquared(
                        new Vector2(d.Transform.M41, d.Transform.M42), centre))
                    .Select(d => d.ModelPath));

        // A model that completed since the previous pass can now acquire its
        // placements. Both outdoor and WMO placement keys are idempotent.
        int placementsBefore = _doodads.InstanceCount;
        PopulateDoodads(_residentCentre.Value, reportDiagnostics: false);

        // Newly-resident doodads are not yet in the collision world (it was built
        // at startup / last tile-cross, before they streamed in). Flag it so the
        // Update loop folds them in. Without this, doodad collision is missing
        // for everything that streams in after the initial build.
        if (_doodads.InstanceCount != placementsBefore && ClientGeometryCollision)
        {
            _doodadCollisionPending += Math.Abs(_doodads.InstanceCount - placementsBefore);
            _doodadCollisionDirty = true;
        }
    }

    // Vantage capture / apply / echo moved to Program.DevTools.cs
    // (dev layer, FOUNDATION_PLAN.md section 12).

    /// <summary>
    /// Identify the WMO group(s) under a screen pixel. Builds a pinhole ray from
    /// the camera basis (no projection-matrix inversion, so it can't be tripped
    /// by the GL clip-Z convention) and asks the WMO renderer what boxes it hits.
    /// Result goes to the HUD and the console so it can be copied out.
    /// </summary>
    private void ScreenPick(Vector2 screen)
    {
        if (_wmo is null) return;

        var size = _window.FramebufferSize;
        if (size.X <= 1f || size.Y <= 1f) return;

        // Pixel -> normalised device coords. Screen Y grows down; NDC Y grows up.
        float ndcX = screen.X / size.X * 2f - 1f;
        float ndcY = 1f - screen.Y / size.Y * 2f;

        var cam = _window.Camera;
        var fwd = cam.Forward;
        var right = Vector3.Normalize(Vector3.Cross(fwd, Vector3.UnitZ));
        var up = Vector3.Cross(right, fwd);
        float tanHalf = MathF.Tan(cam.FieldOfViewDegrees * MathF.PI / 180f * 0.5f);
        var dir = Vector3.Normalize(
            fwd + right * (ndcX * tanHalf * cam.AspectRatio) + up * (ndcY * tanHalf));

        _lastPick = _wmo.PickGroups(cam, cam.Position, dir);

        Console.WriteLine($"[pick] {_lastPick.Count} WMO group(s) under cursor (near->far):");
        foreach (var h in _lastPick)
            Console.WriteLine(
                $"[pick]   {h.Path} [{h.GroupIndex}] '{h.Name}' 0x{h.Flags:X8} " +
                $"{(h.Interior ? "INT" : "ext")}{(h.Shell ? " LOD" : "")} " +
                $"v={h.VertexCount} {h.Distance:F0}yd -> {h.Reason}");
    }

    /// <summary>
    /// What the unit renderer needs to know about the player, in the same shape
    /// it will need for every other unit once packets arrive.
    /// </summary>
    private CharacterRenderer.UnitState BuildUnitState() => new()
    {
        Position = _controller?.Position ?? Vector3.Zero,
        Yaw = _controller?.Yaw ?? 0f,
        Grounded = _controller?.Grounded ?? true,
        VerticalVelocity = _controller?.Velocity.Z ?? 0f,
        FallTimeMs = _controller?.FallTimeMs ?? 0f,
        Walking = _walking,
        Flying = _controller?.Flying ?? false,
    };

    /// <summary>
    /// Keep the camera out of the world.
    ///
    /// Two probes from the eye point outward along the orbit direction: a
    /// collision raycast for buildings and trees, and a march against the
    /// terrain height grid. Whichever is closer sets the distance, floored at
    /// MinDistance.
    ///
    /// The terrain part has to be a march rather than a single test at the
    /// camera position, because the camera can clear a ridge while the straight
    /// line between it and the character passes through it — you would see the
    /// character through the hill.
    ///
    /// MinDistance (1.5) times sin(PitchLimit) is about 1.49, comfortably under
    /// EyeHeight, so even fully pitched down the pulled-in camera stays above
    /// the character's feet. Steep terrain immediately behind you can still
    /// clip; so does the real client.
    /// </summary>
    private void ResolveCameraCollision(float dt)
    {
        var cam = _window.Camera;

        if (!_config.Camera.Collision)
        {
            cam.EffectiveDistance = cam.Distance;
            return;
        }

        var eye = cam.EyeTarget;
        var dir = cam.OrbitDirection;
        float clearance = _config.Camera.Clearance;
        float allowed = cam.Distance;

        if (_collision is { IsEmpty: false })
        {
            var hit = _collision.Raycast(eye, dir, cam.Distance + clearance);
            if (hit is not null) allowed = MathF.Min(allowed, hit.Value.Distance - clearance);
        }

        if (_terrain is not null)
        {
            const int steps = 10;
            float step = cam.Distance / steps;

            for (int i = 1; i <= steps; i++)
            {
                float d = step * i;
                if (d > allowed) break;

                var p = eye + dir * d;
                float? ground = _terrain.SampleHeight(p.X, p.Y);
                if (ground is null) continue;

                if (p.Z < ground.Value + clearance)
                {
                    allowed = d - step;
                    break;
                }
            }
        }

        allowed = Math.Clamp(allowed, cam.MinDistance, cam.Distance);

        // In immediately, out gradually.
        cam.EffectiveDistance = allowed < cam.EffectiveDistance
            ? allowed
            : MathF.Min(allowed, cam.EffectiveDistance + _config.Camera.RestoreSpeed * dt);
    }

    public void Render(float dt)
    {
        long renderSpanStarted = Stopwatch.GetTimestamp();

        ApplyAtmosphere();
        _gpuProfiler?.BeginFrame();

        long worldStarted = Stopwatch.GetTimestamp();

        // Sky first, depth writes off, so everything else draws over it. This
        // replaces nothing yet - ClientWindow still clears to the fog colour, so
        // if the sky pass is disabled the old flat behaviour is exactly what is
        // left (PLAN_09 §1.1: do not remove the clear-colour trick before the
        // replacement is proven, or the far clip becomes a visible edge).
        _sky?.Render(_window.Camera, _atmosphere);

        _gpuProfiler?.Begin(GpuFrameProfiler.Pass.Terrain);
        if (_terrain is not null) _terrain.Render(_window.Camera);
        _gpuProfiler?.End(GpuFrameProfiler.Pass.Terrain);

        UpdatePortalFillLight();

        _gpuProfiler?.Begin(GpuFrameProfiler.Pass.Wmo);
        if (_wmo is not null) _wmo.OcclusionWorld = _collision;
        _wmo?.Render(_window.Camera);
        _gpuProfiler?.End(GpuFrameProfiler.Pass.Wmo);

        _gpuProfiler?.Begin(GpuFrameProfiler.Pass.Doodads);
        _doodads?.Render(_window.Camera);
        _gpuProfiler?.End(GpuFrameProfiler.Pass.Doodads);

        // Ground-effect foliage: scatter near the camera (throttled internally),
        // then draw it into the opaque world pass so terrain/water depth-interact.
        long foliageStarted = Stopwatch.GetTimestamp();
        if (_foliage is not null && _adts is not null && _terrain is not null)
        {
            _foliage.Time += dt;
            _foliage.Scatter(_window.Camera, _adts, _terrain.LoadedTiles, _terrain);
            _foliage.Render(_window.Camera);
        }
        _foliageRenderMilliseconds = Stopwatch.GetElapsedTime(foliageStarted).TotalMilliseconds;

        // Scatter and Render are separate jobs on separate schedules - Render
        // every frame and cheap, Scatter about once a second while walking and
        // a full rebuild. Averaged together they read as a small constant cost
        // and hide a periodic spike, so they are now reported apart. The
        // combined number stays as the bracket that must still sum.
        // ThisFrame, not the sticky value. See FoliageRenderer's note: feeding
        // the sticky one to the phase split made DominantPhase call every hitch
        // "foliage-rescatter" on the strength of a number bigger than the frame.
        _foliageScatterMilliseconds = _foliage?.ScatterMillisecondsThisFrame ?? 0;

        // Particles LAST in the world pass. They are transparent and depth-write
        // is off, so everything opaque must already be in the depth buffer or
        // they draw over walls they are standing behind.
        if (_particles is not null && _doodads is not null)
        {
            var eye = _window.Camera.Position;
            _particles.Simulate(dt, eye,
                _doodads.EmitterInstances(eye, _particles.SimulationDistance));
            _particles.Render(_window.Camera);
            _particleSimulateMilliseconds = _particles.SimulateMilliseconds;
            _particleDrawMilliseconds = _particles.DrawMilliseconds;
        }
        _foliageDrawMilliseconds = _foliage?.DrawMilliseconds ?? 0;

        _worldRenderMilliseconds = Stopwatch.GetElapsedTime(worldStarted).TotalMilliseconds;

        long characterStarted = Stopwatch.GetTimestamp();
        _gpuProfiler?.Begin(GpuFrameProfiler.Pass.Character);
        if (_character is not null && _controller is not null)
            _character.Render(_window.Camera, BuildUnitState());
        _gpuProfiler?.End(GpuFrameProfiler.Pass.Character);
        _characterRenderMilliseconds = Stopwatch.GetElapsedTime(characterStarted).TotalMilliseconds;

        // Streamed creatures/NPCs (networked). Opaque M2s like the player, so they
        // belong here in the opaque pass, before transparent water/particles blend.
        DrawCreatures();

        // Water draws AFTER the character, on purpose. It tests depth but does not
        // write it, so a surface in front of a submerged character blends over him
        // (you see the waterline climb his body) while the near bank still occludes
        // it. Then, if the camera eye itself is below a water surface, tint the
        // whole screen so it reads as being underwater.
        long liquidStarted = Stopwatch.GetTimestamp();
        if (_liquid is not null)
        {
            _liquid.Time += dt;

            // The walking wake (PLAN_16). The gate lives HERE rather than inside
            // LiquidRenderer because this is the only place that knows where the
            // player's feet are.
            //
            // "In water" means a liquid surface sits ABOVE the feet and the feet
            // are not far below it - so wading leaves a trail, walking a bridge
            // over a river does not, and a swimmer well under the surface does
            // not either. Three cases, one test.
            if (_controller is not null)
            {
                var feet = _controller.Position;

                // NOTE the 2-argument overload. PLAN_16 section 4.3 claimed a
                // 3-argument TryGetSurface taking a query Z; that was added by
                // PLAN_15 and went away with its revert. The plan was wrong, not
                // the code. The height test below does the same job for this gate,
                // and using the existing overload means the shared water query is
                // not touched at all.
                bool inWater =
                    _liquid.TryGetSurface(feet.X, feet.Y, out float wakeZ, out _)
                    && wakeZ > feet.Z
                    && wakeZ - feet.Z < WakeMaxWadeDepth;

                _liquid.UpdateWake(feet, _controller.Yaw, dt, inWater);
            }

            _liquid.Render(_window.Camera);

            var eye = _window.Camera.Position;
            if (_liquid.TryGetSurface(eye.X, eye.Y, out float surfaceZ, out byte liquidType)
                && eye.Z < surfaceZ)
            {
                _liquid.RenderUnderwater(surfaceZ - eye.Z, liquidType);
            }
        }
        _liquidRenderMilliseconds = Stopwatch.GetElapsedTime(liquidStarted).TotalMilliseconds;

        // Last, so it draws over the world it describes.
        long debugStarted = Stopwatch.GetTimestamp();
        _gpuProfiler?.Begin(GpuFrameProfiler.Pass.Debug);
        _collisionDebug?.Render(
            _window.Camera,
            MathF.Cos(_config.Movement.MaxSlopeDegrees * MathF.PI / 180f),
            _collision?.Offset ?? Vector3.Zero);

        HighlightPhysicsTriangles();
        DrawPortalDebug();

        if (_showPlayerMarker && _collisionDebug is not null && _controller is not null)
            _collisionDebug.RenderPlayerMarker(
                _window.Camera,
                _controller.Position,
                _config.Movement.Radius,
                _config.Movement.Height,
                _controller.Yaw);
        _gpuProfiler?.End(GpuFrameProfiler.Pass.Debug);
        _gpuProfiler?.EndFrame();
        _debugRenderMilliseconds = Stopwatch.GetElapsedTime(debugStarted).TotalMilliseconds;

        // FFXGlow whole-scene bloom over the finished world + particles, before the
        // curtain and HUD so neither blooms (benilla composites its UI over an
        // already-glowed world). Additive glow-only: the base scene is untouched.
        DrawGlueScene(); // Phase 2 login glue scene (UI_MainMenu), networked + pre-world only
        DrawCharacterSelectScene(); // character-select per-race booth (UI_<Race>), CharacterSelect only
        _glow?.Apply();

        // The loading curtain over the still-streaming world. Drawn last so it
        // covers everything beneath it; fades out when the world is ready.
        if (_loadScreen is not null) DrawLoadingScreen();

        _renderSpanMilliseconds = Stopwatch.GetElapsedTime(renderSpanStarted).TotalMilliseconds;

        // Self-test stall, deliberately after the render span closes so it
        // lands in no measured phase and reports as unaccounted time - which is
        // exactly the field it exists to prove works (PLAN_07 section 7).
        if (_hitch.PendingForcedStallMs > 0)
        {
            int ms = (int)_hitch.PendingForcedStallMs;
            _hitch.PendingForcedStallMs = 0;
            System.Threading.Thread.Sleep(ms);
        }
    }

    private void ApplyAtmosphere()
    {
        _atmosphere.Evaluate();
        _window.SkyColor = _atmosphere.SkyColor;
        _window.Camera.FarPlane = _coupleFarPlaneToFog && _atmosphere.CullAtFogEnd
            ? MathF.Min(_config.Render.FarPlane, _atmosphere.FogEnd + 50f)
            : _config.Render.FarPlane;

        void ApplyTerrain(TerrainRenderer renderer)
        {
            renderer.SunDirection = _atmosphere.SunDirection;
            renderer.SunColor = _atmosphere.SunColor;
            renderer.SunIntensity = _atmosphere.SunIntensity;
            renderer.AmbientColor = _atmosphere.AmbientColor;
            renderer.AmbientIntensity = _atmosphere.AmbientIntensity;
            renderer.FogColor = _atmosphere.FogColor;
            renderer.FogStart = _atmosphere.ShaderFogStart;
            renderer.FogEnd = _atmosphere.ShaderFogEnd;
            renderer.VisibilityDistance = _atmosphere.VisibilityDistance;
        }

        void ApplyWmo(WmoRenderer renderer)
        {
            renderer.SunDirection = _atmosphere.SunDirection;
            renderer.SunColor = _atmosphere.SunColor;
            renderer.SunIntensity = _atmosphere.SunIntensity;
            renderer.AmbientColor = _atmosphere.AmbientColor;
            renderer.AmbientIntensity = _atmosphere.AmbientIntensity;
            renderer.FogColor = _atmosphere.FogColor;
            renderer.FogStart = _atmosphere.ShaderFogStart;
            renderer.FogEnd = _atmosphere.ShaderFogEnd;
            renderer.VisibilityDistance = _atmosphere.VisibilityDistance;
        }

        void ApplyDoodads(DoodadRenderer renderer)
        {
            renderer.SunDirection = _atmosphere.SunDirection;
            renderer.SunColor = _atmosphere.SunColor;
            renderer.SunIntensity = _atmosphere.SunIntensity;
            renderer.AmbientColor = _atmosphere.AmbientColor;
            renderer.AmbientIntensity = _atmosphere.AmbientIntensity;
            renderer.FogColor = _atmosphere.FogColor;
            renderer.FogStart = _atmosphere.ShaderFogStart;
            renderer.FogEnd = _atmosphere.ShaderFogEnd;
            renderer.VisibilityDistance = _atmosphere.VisibilityDistance;
        }

        void ApplyCharacter(CharacterRenderer renderer)
        {
            renderer.SunDirection = _atmosphere.SunDirection;
            renderer.SunColor = _atmosphere.SunColor;
            renderer.SunIntensity = _atmosphere.SunIntensity;
            renderer.AmbientColor = _atmosphere.AmbientColor;
            renderer.AmbientIntensity = _atmosphere.AmbientIntensity;
            renderer.FogColor = _atmosphere.FogColor;
            renderer.FogStart = _atmosphere.ShaderFogStart;
            renderer.FogEnd = _atmosphere.ShaderFogEnd;
        }

        if (_terrain is not null) ApplyTerrain(_terrain);
        if (_wmo is not null) ApplyWmo(_wmo);
        if (_doodads is not null) ApplyDoodads(_doodads);
        if (_character is not null) ApplyCharacter(_character);

        if (_liquid is not null)
        {
            _liquid.SunDirection = _atmosphere.SunDirection;
            _liquid.SunColor = _atmosphere.SunColor;
            _liquid.SunIntensity = _atmosphere.SunIntensity;
            _liquid.AmbientColor = _atmosphere.AmbientColor;
            _liquid.AmbientIntensity = _atmosphere.AmbientIntensity;
            _liquid.FogColor = _atmosphere.FogColor;
            _liquid.FogStart = _atmosphere.ShaderFogStart;
            _liquid.FogEnd = _atmosphere.ShaderFogEnd;

            // PLAN_12. Water colours arrive through the same object and the same
            // gate as the sky, so turning authored lighting off takes the water
            // with it - they cannot disagree about whether to believe the data.
            _liquid.HasAuthoredColors = _atmosphere.AuthoredWaterReady;
            _liquid.OceanClose = _atmosphere.OceanCloseColor;
            _liquid.OceanFar = _atmosphere.OceanFarColor;
            _liquid.RiverClose = _atmosphere.RiverCloseColor;
            _liquid.RiverFar = _atmosphere.RiverFarColor;
            _liquid.OceanAlphaShallow = _atmosphere.OceanShallowAlpha;
            _liquid.OceanAlphaDeep = _atmosphere.OceanDeepAlpha;
            _liquid.RiverAlphaShallow = _atmosphere.RiverShallowAlpha;
            _liquid.RiverAlphaDeep = _atmosphere.RiverDeepAlpha;
        }

        if (_foliage is not null)
        {
            _foliage.SunDirection = _atmosphere.SunDirection;
            _foliage.SunColor = _atmosphere.SunColor;
            _foliage.SunIntensity = _atmosphere.SunIntensity;
            _foliage.AmbientColor = _atmosphere.AmbientColor;
            _foliage.AmbientIntensity = _atmosphere.AmbientIntensity;
            _foliage.FogColor = _atmosphere.FogColor;
            _foliage.FogStart = _atmosphere.ShaderFogStart;
            _foliage.FogEnd = _atmosphere.ShaderFogEnd;
        }
    }

    public void Gui()
    {
        // THE SETTINGS MODAL IS DRAWN FIRST, AND DELIBERATELY ABOVE THE RETURN
        // BELOW. It is the PLAYER's surface - the Escape menu - so it must exist
        // in a shipping build where all the developer tooling is off. Moving this
        // call after the DevTools check would reproduce exactly the seam
        // violation the handbook already records against UpdateLightProbe.
        DrawSettingsModal();

        NetHud(); // Phase 2 network status window (draws only when server.enabled)

        // Master dev-tooling switch (FOUNDATION_PLAN.md section 12): the whole
        // in-game overlay is developer tooling and is skipped in a release build.
        if (!_config.DevTools) return;

        ImGui.SetNextWindowPos(new Vector2(12, 12), ImGuiCond.FirstUseEver);
        ImGui.SetNextWindowSize(new Vector2(430, 0), ImGuiCond.FirstUseEver);

        if (ImGui.Begin("MSUI Client", ImGuiWindowFlags.NoCollapse))
        {
            ImGui.Text($"{_window.Fps:F0} fps   {_window.FrameMs:F2} ms");

            // VSync and multisampling moved to the settings modal (Escape).
            // They are preferences, not instruments - PLAN_11 section 6. VSync is
            // still worth flipping as a DIAGNOSTIC (SYSTEM_STREAMING.md 5A.17),
            // but the modal is one keypress away and two copies of a switch is
            // how two surfaces start disagreeing about the truth.
            ImGui.TextDisabled("Esc - game menu / video settings");

            DrawUiSkinPanel();

            if (ImGui.CollapsingHeader("Scene and vantage", ImGuiTreeNodeFlags.DefaultOpen))
            {
            _vantages ??= VantageStore.Load(_config.RepoRoot);

            ImGui.InputText("Name##vantage", ref _vantageNameInput, 64u);
            ImGui.SameLine();
            if (ImGui.Button("Save##vantage") && !string.IsNullOrWhiteSpace(_vantageNameInput))
            {
                var saved = CaptureVantage(_vantageNameInput.Trim());
                _vantages.Upsert(saved);
                _currentVantage = saved.Name;
                Console.WriteLine(VantageLine("saved", saved));
            }
            ImGui.SameLine();
            if (ImGui.Button("Dump scene (F9)")) DumpScene();

            if (_currentVantage is not null)
            {
                ImGui.SameLine();
                if (ImGui.Button("Reload (F8)"))
                {
                    var cur = _vantages.Find(_currentVantage);
                    if (cur is not null) ApplyVantage(cur);
                }
                ImGui.TextDisabled($"current: {_currentVantage}");
            }

            if (_vantages.All.Count > 0)
            {
                foreach (var saved in _vantages.All)
                {
                    if (ImGui.Button($"Load##v_{saved.Name}")) ApplyVantage(saved);
                    ImGui.SameLine();
                    ImGui.Text(saved.Name);
                }
            }
            }

            DrawHitchPanel();
            DrawLightProbePanel();

            if (ImGui.CollapsingHeader("Performance - CPU draw submission", ImGuiTreeNodeFlags.DefaultOpen))
            {
            ImGui.Text($"  update {_updateMilliseconds,6:F2} ms  " +
                       $"move {_movementMilliseconds,5:F2}  residency {_residencyMilliseconds,5:F2}");
            ImGui.Text($"  preload {_preloadMilliseconds,5:F2} ms  " +
                       $"unit {_characterUpdateMilliseconds,5:F2}  camera {_cameraCollisionMilliseconds,5:F2}");
            ImGui.Text($"  world {_worldRenderMilliseconds,6:F2} ms  " +
                       $"character {_characterRenderMilliseconds,5:F2} ms  " +
                       $"debug {_debugRenderMilliseconds,5:F2} ms");
            if (_terrain is not null)
                ImGui.Text($"  terrain {_terrain.RenderMilliseconds,6:F2} ms  " +
                           $"{_terrain.DrawCallsLastFrame,5:N0} calls  " +
                           $"{_terrain.TrianglesLastFrame,10:N0} tris");
            if (_wmo is not null)
            {
                ImGui.Text($"  WMO     {_wmo.RenderMilliseconds,6:F2} ms  " +
                           $"{_wmo.DrawCallsLastFrame,5:N0} calls  " +
                           $"{_wmo.TrianglesLastFrame,10:N0} tris");
                ImGui.Text($"          {_wmo.DrawnLastFrame:N0} instance(s), " +
                           $"{_wmo.VisibleGroupsLastFrame:N0} group(s)");
            }
            if (_doodads is not null)
                ImGui.Text($"  doodad  {_doodads.RenderMilliseconds,6:F2} ms  " +
                           $"{_doodads.DrawCallsLastFrame,5:N0} calls  " +
                           $"{_doodads.TrianglesLastFrame,10:N0} tris  " +
                           $"{_doodads.DrawnLastFrame:N0} inst");

            ImGui.Text("GPU time - delayed, non-blocking");
            if (_gpuProfiler is { HasResults: true } gpu)
            {
                ImGui.Text($"  measured {gpu.MeasuredTotalMilliseconds,6:F2} ms  " +
                           $"terrain {gpu[GpuFrameProfiler.Pass.Terrain],5:F2}  " +
                           $"WMO {gpu[GpuFrameProfiler.Pass.Wmo],5:F2}");
                ImGui.Text($"  doodad {gpu[GpuFrameProfiler.Pass.Doodads],5:F2} ms  " +
                           $"character {gpu[GpuFrameProfiler.Pass.Character],5:F2}  " +
                           $"debug {gpu[GpuFrameProfiler.Pass.Debug],5:F2}");
            }
            else
            {
                ImGui.Text("  warming up...");
            }
            }

            if (ImGui.CollapsingHeader("Atmosphere and visibility test", ImGuiTreeNodeFlags.DefaultOpen))
            {

            // Time of day is the ONE control both surfaces keep. It is a
            // preference when it is cycling and an instrument when it is pinned,
            // and pinning it to compare two frames is worth not having to open a
            // modal for. Everything else that used to live here - sun and ambient
            // strength, the three fog controls, far-plane coupling and the
            // vanilla-visibility preset - is now Escape / Graphics.
            float time = _atmosphere.TimeOfDayHours;
            if (ImGui.SliderFloat("Time of day", ref time, 0f, 24f, "%.2f h"))
                _atmosphere.TimeOfDayHours = time;

            if (ImGui.Button("Noon")) _atmosphere.SetDay();
            ImGui.SameLine();
            if (ImGui.Button("Sunset")) _atmosphere.SetSunset();
            ImGui.SameLine();
            if (ImGui.Button("Night")) _atmosphere.SetNight();

            ImGui.TextDisabled(
                $"fog {_atmosphere.FogStart:F0} -> {_atmosphere.FogEnd:F0} yd" +
                $"{(_atmosphere.FogEnabled ? "" : " (off)")}" +
                $"{(_atmosphere.CullAtFogEnd ? ", culling past" : "")}");
            ImGui.TextDisabled(
                $"sun x{_atmosphere.SunStrength:F2}  ambient x{_atmosphere.AmbientStrength:F2}  " +
                $"{(_atmosphere.HasAuthored ? "authored" : "INVENTED constants")}");

            if (_terrain is not null)
            {
                ImGui.Text($"startup preload: " +
                           $"{(_config.Start.DrainPreloadsAtStartup ? "blocking outer ring" : "visible first / background outer ring")}");
                ImGui.Text($"tiles {_terrain.TileCount}   drawn {_terrain.DrawnLastFrame}");
                ImGui.Text($"triangles {_terrain.TotalTriangles:N0}");
                if (_residentCentre is { } resident)
                    ImGui.Text($"resident [{resident.col},{resident.row}]  " +
                               $"objects {ObjectResidencyRadius:F0} yd  " +
                               $"last {_lastStreamSeconds:F2}s");
                if (_wmo is not null)
                    ImGui.Text($"WMO preload {WmoPreloadRadius * 2 + 1}x{WmoPreloadRadius * 2 + 1}  " +
                               $"{_wmo.PendingPreloads} queued");
                if (_doodads is not null)
                {
                    ImGui.Text($"M2 preload {_doodads.PendingPreloads} queued  " +
                               $"discovery {_backgroundDiscovery.Count} tile(s)");
                    ImGui.Text($"M2 demand {(_demandStreamDoodads ? "on" : "off")}, " +
                               $"radius {DoodadDemandRadius:F0} yd");
                }
            }

            if (_controller is not null)
            {
                var p = _controller.Position;

                ImGui.Separator();
                ImGui.Text("Position (WoW space)");
                ImGui.Text($"  X {p.X,10:F2}   north");
                ImGui.Text($"  Y {p.Y,10:F2}   west");
                ImGui.Text($"  Z {p.Z,10:F2}   up");

                var (col, row) = TerrainRenderer.TileAt(p.X, p.Y);
                ImGui.Text($"  tile [{col}, {row}]");
                ImGui.Text($"  facing {_controller.Yaw * 180f / MathF.PI,5:F0} deg");

                ImGui.Separator();
                ImGui.Text("Movement");

                ImGui.Text(_controller.GroundZ is float g
                    ? $"  ground {g,10:F2}   (delta {p.Z - g,6:F2})"
                    : "  ground     (no data)");

                // WHICH of the two is holding you up. This is the line that
                // separates a misplaced collision mesh from terrain doing it.
                ImGui.Text(_controller.TerrainGroundZ is float tz
                    ? $"    terrain   {tz,9:F2}"
                    : "    terrain     (none)");
                ImGui.Text(_controller.CollisionGroundZ is float cz
                    ? $"    collision {cz,9:F2}"
                    : "    collision   (none)");
                ImGui.TextColored(new Vector4(0.6f, 0.9f, 1f, 1f),
                    $"    standing on {_controller.GroundSource}");

                // Terrain holes: the MCNK 0x3C mask, which is how a dungeon
                // entrance is cut through a hillside. Standing in one means the
                // height grid deliberately has no answer and collision has to.
                if (_controller.InTerrainHole)
                    ImGui.TextColored(new Vector4(1f, 0.85f, 0.4f, 1f),
                        "    in terrain hole (dungeon cut)");
                if (_controller.GroundTriangle >= 0 && _collision is not null)
                    ImGui.Text($"    surface tri {_controller.GroundTriangle} " +
                               $"({_collision.SourceOf(_controller.GroundTriangle)})");

                if (_controller.GroundProbeOffset.LengthSquared() > 1e-6f)
                    ImGui.Text($"    support probe ({_controller.GroundProbeOffset.X,5:F2}," +
                               $" {_controller.GroundProbeOffset.Y,5:F2})");

                if (_controller.GroundProbesLastFrame > 1)
                    ImGui.Text($"    support fan {_controller.GroundProbesLastFrame} probes");

                if (_controller.GroundAdhesion)
                    ImGui.TextColored(new Vector4(0.6f, 0.9f, 1f, 1f),
                        "    ground adhesion");

                ImGui.Text($"  state  {(_controller.Flying ? "flying" : _controller.Grounded ? "grounded" : "airborne")}");
                ImGui.Text($"  vz     {_controller.Velocity.Z,10:F2}");

                if (_controller.FallTimeMs > 0)
                    ImGui.Text($"  fall   {_controller.FallTimeMs,10:F0} ms");

                float groundSnap = _config.Movement.GroundSnapDistance;
                if (ImGui.SliderFloat("Ground snap down", ref groundSnap, 0f, 1.5f, "%.2f yd"))
                    _config.Movement.GroundSnapDistance = groundSnap;

                float fallDelay = _config.Movement.FallAnimationDelayMs;
                if (ImGui.SliderFloat("Fall animation delay", ref fallDelay, 0f, 500f, "%.0f ms"))
                    _config.Movement.FallAnimationDelayMs = fallDelay;

                float runSpeed = _config.Movement.RunSpeed;
                if (ImGui.SliderFloat("Run speed", ref runSpeed, 1f, 12f, "%.2f yd/s"))
                    _config.Movement.RunSpeed = runSpeed;

                float walkSpeed = _config.Movement.WalkSpeed;
                if (ImGui.SliderFloat("Walk speed", ref walkSpeed, 0.5f, 6f, "%.2f yd/s"))
                    _config.Movement.WalkSpeed = walkSpeed;

                float backwardSpeed = _config.Movement.BackwardSpeed;
                if (ImGui.SliderFloat("Backward speed", ref backwardSpeed, 0.5f, 8f, "%.2f yd/s"))
                    _config.Movement.BackwardSpeed = backwardSpeed;

                // This one matters: it is the loud version of the failure that
                // once looked like a physics bug for 23 seconds of falling.
                if (_controller.NoGroundBelow)
                    ImGui.TextColored(new Vector4(1f, 0.45f, 0.35f, 1f),
                        "  NO GROUND — off tiles or missing MCVT");

                // Dungeon entry. These two switches together are the difference
                // between walking into the gold mine and climbing the mountain
                // it is dug into, so they get their own group rather than
                // hiding among the speed sliders.
                ImGui.Separator();
                ImGui.Text("Dungeon entry (1.12)");

                if (_terrain is not null)
                {
                    bool holes = _terrain.ApplyHoles;
                    if (ImGui.Checkbox("Terrain holes cut ground", ref holes))
                        _terrain.ApplyHoles = holes;
                    if (ImGui.IsItemHovered())
                        ImGui.SetTooltip(
                            "MCNK 0x3C holes: a uint16 per chunk, 4x4 bits, each bit\n" +
                            "covering a 2x2 block of the chunk's 8x8 quads. The mesh has\n" +
                            "always skipped these; the height grid did not, so the player\n" +
                            "stood on invisible ground across a mine mouth.\n" +
                            "Off = the old behaviour.");

                    ImGui.TextDisabled($"  {_terrain.HoleQuadCount} holed quad(s) loaded");
                }

                bool precedence = _controller.VanillaHeightPrecedence;
                if (ImGui.Checkbox("Vanilla height precedence", ref precedence))
                    _controller.VanillaHeightPrecedence = precedence;
                if (ImGui.IsItemHovered())
                    ImGui.SetTooltip(
                        "Map::GetHeight: the collision surface wins when it is HIGHER\n" +
                        "than terrain, or when you are already under terrain and it is\n" +
                        "CLOSER. Off = highest-surface-wins, which can never put you in\n" +
                        "a tunnel because a mine floor is below the mountain above it.");

                float slack = _controller.UndergroundSlack;
                if (ImGui.SliderFloat("Underground slack", ref slack, 0.05f, 4f, "%.2f yd"))
                    _controller.UndergroundSlack = slack;
                if (ImGui.IsItemHovered())
                    ImGui.SetTooltip(
                        "How far below terrain the feet must be before the closer-surface\n" +
                        "rule may pick a lower floor. Vanilla's server constant is 0.05,\n" +
                        "but walking uphill puts the feet ~0.16 yd under terrain for a\n" +
                        "frame, so that value here drops you through the world.");
            }
            }

            DrawPortalPanel();
            DrawInstancesPanel();
            DrawParticlesPanel();

            if (ImGui.CollapsingHeader("Buildings", ImGuiTreeNodeFlags.DefaultOpen))
            {
            if (_wmo is not null)
            {
                ImGui.Text($"  {_wmo.InstanceCount} placed, {_wmo.DrawnLastFrame} drawn");
                ImGui.Text($"  {_wmo.ModelCount} model(s), {_wmo.TextureCount} texture(s)");
                ImGui.Text($"  {_wmo.TotalTriangles:N0} triangles");

                // Every switch and slider that used to live here is now
                // Escape / Graphics / Advanced - buildings. What is left is the
                // readout half, which is what actually answers "why is that
                // building missing" (PLAN_11 section 6).
                ImGui.TextDisabled(
                    $"  draw {(_wmo.Enabled ? "on" : "OFF")}  " +
                    $"frustum {(_wmo.FrustumCulling ? "on" : "off")}  " +
                    $"shells {(_wmo.UseDistanceLodShells ? "on" : "off")}  " +
                    $"two-sided {(_wmo.ForceTwoSided ? "on" : "off")}");
                ImGui.TextDisabled(
                    $"  distance {_wmo.DrawDistance:F0} yd  alpha {_wmo.AlphaCutoff:F2}  " +
                    $"MOCV {(_wmo.UseVertexColors ? $"x{_wmo.VertexColorScale:F2}" : "off")}");
                ImGui.TextDisabled(
                    $"  impostor <= {_wmo.ImpostorMaxVertices} verts  " +
                    $"inside margin {_wmo.InsideInstanceMargin:F0}  " +
                    $"interior cull {_wmo.InteriorCullDistance:F0}  " +
                    $"guard {_wmo.ShellNearGuard:F0}");

                ImGui.Text($"  LOD shells hidden nearby: {_wmo.LodGroupsCulledLastFrame}");
                ImGui.Text($"  occluded groups: {_wmo.OccludedGroupsLastFrame}" +
                           $"{(_wmo.OcclusionCulling ? "" : "  (occlusion off)")}");

                float interiorBright = _wmo.InteriorBrightness;
                ImGui.SetNextItemWidth(160f);
                if (ImGui.SliderFloat("Interior brightness", ref interiorBright, 0.5f, 3f, "%.2f"))
                    _wmo.InteriorBrightness = interiorBright;
                ImGui.TextDisabled("   brightens MOCV-lit interiors (Deadmines etc.); exterior untouched");

                bool visTrace = _wmo.VisTrace;
                if (ImGui.Checkbox("Console visibility trace", ref visTrace))
                    _wmo.VisTrace = visTrace;
                ImGui.SameLine();
                bool dumpGroups = _wmo.DumpLargeWmoGroups;
                if (ImGui.Checkbox("Dump groups on load", ref dumpGroups))
                    _wmo.DumpLargeWmoGroups = dumpGroups;

                if (_wmo.LargestWmoGroupCount > 0)
                    ImGui.TextColored(new Vector4(0.6f, 0.9f, 1f, 1f),
                        $"  {_wmo.LargestWmoName}: inside={_wmo.LastInsideCity}  " +
                        $"shells {_wmo.ShellsDrawnLastFrame} drawn / {_wmo.ShellsHiddenLastFrame} hidden  " +
                        $"groups {_wmo.LargestWmoGroupsDrawn}/{_wmo.LargestWmoGroupCount}");

                ImGui.Separator();
                ImGui.Text("Group picker: MIDDLE-CLICK anything (or crosshair button)");
                if (ImGui.Button("Pick under crosshair"))
                    _lastPick = _wmo.PickGroups(_window.Camera, _window.Camera.Position, _window.Camera.Forward);
                ImGui.SameLine();
                if (ImGui.Button("Clear pick")) _lastPick.Clear();
                foreach (var h in _lastPick)
                    ImGui.Text($"  {h.Path} [{h.GroupIndex,3}] '{h.Name}' 0x{h.Flags:X8} " +
                               $"{(h.Interior ? "INT" : "ext")}{(h.Shell ? " LOD" : "")} " +
                               $"v={h.VertexCount} {h.Distance:F0}yd -> {h.Reason}");

                if (_lastPick.Count > 0 && _overrides is not null)
                {
                    var top = _lastPick[0];
                    ImGui.TextDisabled($"override [{top.GroupIndex}] '{top.Name}' in {top.Path}:");
                    if (ImGui.Button("Hide inside##ov"))
                        _overrides.Set(top.Root, top.Path, top.GroupIndex, OverrideRule.HideInside,
                            "hidden once inside the city", _currentVantage ?? "");
                    ImGui.SameLine();
                    if (ImGui.Button("Hide always##ov"))
                        _overrides.Set(top.Root, top.Path, top.GroupIndex, OverrideRule.Hide,
                            "hidden everywhere", _currentVantage ?? "");
                    ImGui.SameLine();
                    if (ImGui.Button("Show inside##ov"))
                        _overrides.Set(top.Root, top.Path, top.GroupIndex, OverrideRule.ShowInside,
                            "forced visible inside", _currentVantage ?? "");
                    ImGui.SameLine();
                    if (ImGui.Button("Clear##ov"))
                        _overrides.Remove(top.Root, top.GroupIndex);
                }

                if (_overrides is not null && _overrides.All.Count > 0)
                {
                    ImGui.TextDisabled("active overrides:");
                    foreach (var ov in _overrides.All)
                        ImGui.TextDisabled($"  {ov.RootFile} [{ov.GroupIndex}] {ov.Rule}");
                }
            }
            else
            {
                ImGui.Text("  none loaded");
            }

            if (_doodads is not null)
            {
                ImGui.Separator();
                ImGui.Text("Doodads");
                ImGui.Text($"  {_doodads.InstanceCount:N0} placed, {_doodads.DrawnLastFrame:N0} drawn");
                ImGui.Text($"  {_doodads.ModelCount} model(s), {_doodads.CollisionModels} with collision");
                ImGui.Text($"  {_doodads.TotalTriangles:N0} triangles");
                ImGui.Text($"  {_doodads.InteriorLitCount:N0} with baked interior light");

                // Moved to Escape / Graphics / Advanced - doodads: draw, frustum
                // cull, GPU instancing, flat cull bounds, MODD interior light and
                // its brightness, alpha cut and draw distance. The A/B arguments
                // that used to be comments here are now the tooltips on those
                // controls, so the reason lives beside the switch.
                //
                // The one that matters for measurement: flat cull bounds was
                // 55.8 ms -> 0.3 ms on a crossing frame, and PLAN_08 section 7
                // step 3 says it gets backed out if the number does not move.
                // Diff `cull` in the [hitch] doodad line, not this panel.
                ImGui.TextDisabled(
                    $"  draw {(_doodads.Enabled ? "on" : "OFF")}  " +
                    $"frustum {(_doodads.FrustumCulling ? "on" : "off")}  " +
                    $"instanced {(_doodads.UseInstancing ? "on" : "off")}  " +
                    $"flat bounds {(_doodads.FlatCullBounds ? "on" : "off")}");
                ImGui.TextDisabled(
                    $"  distance {_doodads.DrawDistance:F0} yd  alpha {_doodads.AlphaCutoff:F2}  " +
                    $"MODD {(_doodads.InteriorLighting ? $"x{_doodads.VertexColorScale:F2}" : "off")}");
            }
            }

            if (ImGui.CollapsingHeader("Character"))
            {
            if (_character is not null)
            {
                ImGui.Text($"  {_character.Race} {_character.Gender}");
                ImGui.Text($"  {_character.BoneCount} bones, {_character.ClipCount} clip(s)");

                if (_character.BoneOverflow)
                    ImGui.TextColored(new Vector4(1f, 0.45f, 0.35f, 1f),
                        "  TOO MANY BONES - animation disabled, see the console");
                ImGui.Text($"  {_character.VisiblePieces}/{_character.PieceCount} geoset(s) drawn");

                // Head-texture status (the "gear texture on the head" bug). Green = the scalp is
                // covered by a hair geoset; red = the bald base body shows through.
                if (_character.ScalpCovered)
                    ImGui.TextColored(new Vector4(0.5f, 0.95f, 0.55f, 1f), $"  head: {_character.HairResolution}");
                else
                    ImGui.TextColored(new Vector4(1f, 0.4f, 0.35f, 1f), $"  HEAD ISSUE: {_character.HairResolution}");
                if (ImGui.TreeNode("Head / hair geosets"))
                {
                    foreach (var hline in _character.HeadDiag) ImGui.TextUnformatted("  " + hline);
                    ImGui.TreePop();
                }
                if (ImGui.Button("Capture diagnostics -> file")) _character.SaveDiagnostics();
                if (_character.LastDiagnosticPath is not null)
                {
                    ImGui.TextColored(new Vector4(0.6f, 0.9f, 1f, 1f), "  saved - send me this file:");
                    ImGui.TextDisabled("  " + _character.LastDiagnosticPath);
                }

                if (_character.UnboundSlots > 0)
                    ImGui.TextColored(new Vector4(1f, 0.85f, 0.4f, 1f),
                        $"  {_character.UnboundSlots} texture slot(s) unbound");

                // If ClipTime sits pegged at ClipDuration and never wraps, the
                // clip is being treated as a one-shot and the character will
                // hold its last frame forever.
                ImGui.TextColored(new Vector4(0.6f, 0.9f, 1f, 1f),
                    $"  {_character.ClipName}  {_character.ClipTime:F2}/{_character.ClipDuration:F2}s " +
                    $"x{_character.ClipRate:F2} move {_character.ClipMoveSpeed:F2} " +
                    $"{(_character.ClipLooping ? "loop" : "ONCE")}");
                ImGui.Text($"  ground speed {_character.GroundSpeed,5:F2} yd/s");

                bool drawCharacter = _character.Enabled;
                if (ImGui.Checkbox("Draw character", ref drawCharacter)) _character.Enabled = drawCharacter;

                // FIRST THING TO TRY if the model looks folded or exploded: bind
                // pose makes every skin matrix an exact identity, so what you
                // see is the raw mesh at the placement transform. If bind pose
                // is right and animation is wrong, the bug is in M2Animator; if
                // bind pose is already wrong, it is the transform below.
                bool bind = _character.BindPose;
                if (ImGui.Checkbox("Bind pose (no animation)", ref bind)) _character.BindPose = bind;

                // The one thing arithmetic cannot settle - a bounding box is
                // invariant under a half turn, so only your eyes can say which
                // way the model faces. Line it up with the capsule's spike and
                // tell me the number.
                float heading = _character.HeadingOffsetDegrees;
                if (ImGui.SliderFloat("Heading offset", ref heading, -180f, 180f))
                    _character.HeadingOffsetDegrees = heading;
                ImGui.SameLine();
                if (ImGui.Button("90")) _character.HeadingOffsetDegrees = 90f;

                float modelScale = _character.ModelScale;
                if (ImGui.SliderFloat("Model scale", ref modelScale, 0.25f, 3f))
                    _character.ModelScale = modelScale;

                float zOffset = _character.ZOffset;
                if (ImGui.SliderFloat("Model Z offset", ref zOffset, -2f, 2f))
                    _character.ZOffset = zOffset;

                // Whole body turns to face travel / only the hips turn / a
                // separate sideways clip and nothing turns.
                int strafeStyle = (int)_character.Strafe;
                if (ImGui.Combo("Strafe style", ref strafeStyle,
                        "Split (legs + torso)\0Whole body\0Lower body only\0Sideways clips\0"))
                    _character.Strafe = (CharacterRenderer.StrafeStyle)strafeStyle;

                // How much of the strafe angle the TORSO keeps. The legs always
                // take all of it. 1.0 is the old whole-body mode, 0.0 the old
                // lower-body one, and the real client sits around two thirds.
                float torsoFollow = _character.TorsoFollow;
                if (ImGui.SliderFloat("Torso follow", ref torsoFollow, 0f, 1f))
                    _character.TorsoFollow = torsoFollow;

                ImGui.Text($"  legs {_character.MoveYawDegrees,4:F0} deg" +
                           $"   torso {_character.MoveYawDegrees * _character.TorsoFollow,4:F0} deg");

                int torsoBone = _character.TorsoBone;
                if (ImGui.DragInt("Torso bone (spine)", ref torsoBone, 0.25f, -1,
                        Math.Max(_character.BoneCount - 1, 0)))
                    _character.TorsoBone = torsoBone;

                ImGui.Text($"  strafe angle {_character.MoveYawDegrees,5:F0} deg" +
                           (_character.TwistBone < 0 ? "   HIP BONE NOT FOUND" : ""));

                // Isolates the mechanism from the trigger. Stand still and drag.
                float force = _character.ForceAngleDegrees;
                if (ImGui.SliderFloat("Force angle (deg)", ref force, -120f, 120f))
                    _character.ForceAngleDegrees = force;
                ImGui.SameLine();
                if (ImGui.Button("0")) _character.ForceAngleDegrees = 0f;

                // Ticked: the hip bone's subtree turns, which is the legs.
                // Unticked: everything else turns, which is the upper body.
                bool subtree = _character.TwistSubtree;
                if (ImGui.Checkbox("Twist subtree (legs, not torso)", ref subtree))
                    _character.TwistSubtree = subtree;

                // Where the twist stops. It comes from the key-bone table, which
                // is a convention rather than a guarantee - if the torso turns
                // with the legs, drag this until it does not.
                int hipBone = _character.TwistBone;
                if (ImGui.DragInt("Twist bone (hips)", ref hipBone, 0.25f, -1,
                        Math.Max(_character.BoneCount - 1, 0)))
                    _character.TwistBone = hipBone;

                float maxTwist = _character.MaxTwistDegrees;
                if (ImGui.SliderFloat("Max twist (deg)", ref maxTwist, 0f, 180f))
                    _character.MaxTwistDegrees = maxTwist;

                bool dressed = _dressed;
                if (ImGui.Checkbox("Wear Battlegear of Might", ref dressed))
                {
                    _dressed = dressed;
                    _character.Equipment = dressed
                        ? CharacterEquipment.BattlegearOfMight()
                        : new CharacterEquipment();
                    _character.ApplyEquipment();
                }

                if (_character.Attached is not null)
                {
                    ImGui.Text($"  attached {_character.Attached.DrawnLastFrame}/{_character.Attached.MountCount} drawn");

                    bool drawAttached = _character.Attached.Enabled;
                    if (ImGui.Checkbox("Draw attached items", ref drawAttached))
                        _character.Attached.Enabled = drawAttached;

                    // Attached items are SEPARATE M2 MODELS, not geosets, so the
                    // geoset checkboxes below have no effect on them. Two
                    // mechanisms, two switches.
                    if (ImGui.TreeNode("Attached items"))
                    {
                        foreach (var (label, visible) in _character.Attached.Mounts.ToList())
                        {
                            bool on = visible;
                            if (ImGui.Checkbox($"{label}##att", ref on))
                                _character.Attached.SetMountVisible(label, on);
                        }
                        ImGui.TreePop();
                    }
                }

                // Hair lives in category 0 alongside the base body, so the
                // category checkbox for it would take the whole character with
                // it. This is the switch for testing hair against a helm.
                // Appearance. These are the CharSections lookup keys - flipping
                // them proves the table is finding real rows, and the face and
                // hair should visibly change.
                if (ImGui.TreeNode("Appearance"))
                {
                    int skin = _character.SkinId, face = _character.FaceId;
                    int hairStyle = _character.HairStyleId, hairColour = _character.HairColorId;
                    int facial = _character.FacialHairId;
                    bool changed = false;

                    changed |= ImGui.SliderInt("Skin", ref skin, 0, 10);
                    changed |= ImGui.SliderInt("Face", ref face, 0, 10);
                    changed |= ImGui.SliderInt("Hair style", ref hairStyle, 0, 15);
                    changed |= ImGui.SliderInt("Hair colour", ref hairColour, 0, 10);
                    changed |= ImGui.SliderInt("Facial hair", ref facial, 0, 10);

                    if (changed)
                    {
                        _character.SkinId = skin;
                        _character.FaceId = face;
                        _character.HairStyleId = hairStyle;
                        _character.HairColorId = hairColour;
                        _character.FacialHairId = facial;
                        _character.Reload();
                    }

                    ImGui.TreePop();
                }

                bool hideHair = _character.HideHair;
                if (ImGui.Checkbox("Hide hair", ref hideHair))
                {
                    _character.HideHair = hideHair;
                    _character.ApplyEquipment();
                }

                // FLICKER HUNT. Z-fighting is two surfaces in the same place,
                // so the fastest way to name the pair is to switch one half off
                // and see whether it stops. One checkbox per category that is
                // actually being drawn, with its variant, so the list is short
                // and every entry means something.
                if (ImGui.TreeNode("Geosets drawn"))
                {
                    foreach (var (category, variant) in _character.ActiveGeosets)
                    {
                        bool on = !_character.HiddenCategories.Contains(category);
                        if (ImGui.Checkbox($"cat {category} (variant {variant})##geo{category}", ref on))
                        {
                            if (on) _character.HiddenCategories.Remove(category);
                            else _character.HiddenCategories.Add(category);
                            _character.ApplyEquipment();
                        }
                    }

                    // Soloing beats hiding for z-fighting: a fight needs both
                    // halves, so switching one off only proves a pair stopped.
                    // Stepping through one geoset at a time says which.
                    int solo = _character.SoloGeoset;
                    if (ImGui.SliderInt("Solo one geoset (-1 = all)", ref solo, -1,
                            Math.Max(_character.ActiveGeosets.Count - 1, 0)))
                    {
                        _character.SoloGeoset = solo;
                        _character.ApplyEquipment();
                    }

                    if (ImGui.Button("Show all categories"))
                    {
                        _character.HiddenCategories.Clear();
                        _character.SoloGeoset = -1;
                        _character.ApplyEquipment();
                    }

                    ImGui.TreePop();
                }

                bool allGeosets = _character.ShowAllGeosets;
                if (ImGui.Checkbox("All geosets", ref allGeosets)) _character.ShowAllGeosets = allGeosets;

                bool magenta = _character.MagentaUnbound;
                if (ImGui.Checkbox("Magenta unbound", ref magenta)) _character.MagentaUnbound = magenta;

                float charCut = _character.AlphaCutoff;
                if (ImGui.SliderFloat("Character alpha cut", ref charCut, 0f, 1f))
                    _character.AlphaCutoff = charCut;
            }
            else
            {
                ImGui.Text("  not loaded - see the console");
            }
            }

            if (ImGui.CollapsingHeader("Collision"))
            {
            if (_collision is not null)
            {
                ImGui.Text($"  {_collision.TriangleCount:N0} triangles, {_collision.NodeCount:N0} nodes");
                if (_vmaps is not null)
                    ImGui.Text($"  {_vmaps.SpawnsUsed}/{_vmaps.SpawnsSeen} spawns, " +
                               $"{_vmaps.DistinctUnresolved} model(s) with no .vmo");
                ImGui.Text($"  built in {_collisionBuildSeconds:F1}s");

                if (_collisionDebug is not null)
                {
                    bool show = _collisionDebug.Enabled;
                    if (ImGui.Checkbox("Show collision (C)", ref show))
                        SetCollisionDebugEnabled(show);

                    bool solid = _collisionDebug.Solid;
                    if (ImGui.Checkbox("Solid", ref solid)) _collisionDebug.Solid = solid;

                    // Isolate whatever last blocked you. One building's shell
                    // against that same building rendered is a single glance;
                    // a million triangles of wireframe is not.
                    bool isolate = _collisionDebug.SourceFilter >= 0;
                    if (ImGui.Checkbox("Isolate blocker", ref isolate))
                    {
                        _collisionDebug.SourceFilter = isolate && _controller is not null
                            ? _collision.SourceIdOf(_controller.LastBlockTriangle)
                            : -1;
                    }

                    // Live collision shift. Nudge until the wireframe sits on
                    // the geometry you can see, then bake the value into the
                    // loader and set this back to zero.
                    var offset = _collision.Offset;
                    var raw = new System.Numerics.Vector3(offset.X, offset.Y, offset.Z);
                    if (ImGui.DragFloat3("Collision offset", ref raw, 0.05f, -20f, 20f))
                        _collision.Offset = raw;

                    if (ImGui.Button("Nudge along facing") && _controller is not null)
                    {
                        var f = new Vector3(MathF.Cos(_controller.Yaw), MathF.Sin(_controller.Yaw), 0);
                        _collision.Offset += f * 0.25f;
                    }
                    ImGui.SameLine();
                    if (ImGui.Button("Reset offset")) _collision.Offset = Vector3.Zero;

                    if (_collisionDebug.SourceFilter >= 0)
                        ImGui.Text($"    showing only {_collision.SourceOf(_controller?.LastBlockTriangle ?? -1)}");
                }

                // Live probes. Stand next to something solid and face it: if
                // "ahead" stays empty, the geometry is not where it looks like
                // it is, and that is a data problem rather than a movement one.
                if (_controller is not null)
                {
                    var mid = _controller.Position + new Vector3(0, 0, _config.Movement.Height * 0.5f);
                    var facing = new Vector3(MathF.Cos(_controller.Yaw), MathF.Sin(_controller.Yaw), 0);

                    var ahead = _collision.Raycast(mid, facing, 60f);
                    if (ahead is not null)
                    {
                        var p = ahead.Value.Point;
                        ImGui.Text($"  ahead  {ahead.Value.Distance,6:F2} yd at ({p.X:F1}, {p.Y:F1}, {p.Z:F1})");
                        ImGui.Text($"         from {_collision.SourceOf(ahead.Value.Triangle)}");
                    }
                    else
                    {
                        ImGui.Text("  ahead    nothing within 60");
                    }

                    // What actually stopped you, as opposed to what happens to
                    // be in front of you.
                    if (_controller.HasBlock)
                    {
                        var b = _controller.LastBlockPoint;
                        var n = _controller.LastBlockNormal;
                        ImGui.TextColored(new Vector4(1f, 0.85f, 0.4f, 1f),
                            $"  BLOCKED at ({b.X:F2}, {b.Y:F2}, {b.Z:F2})");
                        ImGui.Text($"    from {_collision.SourceOf(_controller.LastBlockTriangle)}");
                        ImGui.Text($"    normal ({n.X:F2}, {n.Y:F2}, {n.Z:F2})");
                        ImGui.Text($"    you are at ({_controller.Position.X:F2}, " +
                                   $"{_controller.Position.Y:F2}, {_controller.Position.Z:F2})");
                        if (_controller.LastPushOut > 0.001f)
                            ImGui.Text($"    pushed out {_controller.LastPushOut:F2} yd this frame");
                    }
                }
            }
            else
            {
                ImGui.Text("  terrain only (no vmaps)");
            }
            }

            var cam = _window.Camera;
            var cp = cam.Position;
            if (ImGui.CollapsingHeader("Camera", ImGuiTreeNodeFlags.DefaultOpen))
            {
            ImGui.Text($"  {cp.X,9:F1} {cp.Y,9:F1} {cp.Z,9:F1}");
            ImGui.Text($"  yaw {cam.Yaw * 180f / MathF.PI,5:F0}  pitch {cam.Pitch * 180f / MathF.PI,4:F0}  " +
                       $"dist {cam.EffectiveDistance,4:F1}/{cam.Distance,4:F1}");

            // Non-zero orbit means the camera has been swung off the character's
            // back. It should return to 0 the moment you move.
            ImGui.Text($"  orbit {cam.OrbitYaw * 180f / MathF.PI,5:F0} deg   " +
                       $"view {cam.ViewYaw * 180f / MathF.PI,5:F0} deg");

            // Field of view, turn speed, eye height, mouse sensitivity and the
            // raw-cursor switch are now Escape / Camera and controls. They stopped
            // being config-file-plus-restart settings for a good reason - a spell
            // at FOV 45 flattened the world enough to be disliked on sight without
            // it being obvious which knob did it - and the modal keeps them live
            // AND persists them, which is what that episode actually wanted.
            ImGui.TextDisabled(
                $"  fov {cam.FieldOfViewDegrees:F0} deg   turn {_turnSpeed * 180f / MathF.PI:F0} deg/s   " +
                $"eye {cam.EyeHeight:F2}");

            // Mouse-look diagnostics. Read these WHILE dragging - each line
            // eliminates one link in the chain, so "the mouse does nothing"
            // becomes a specific broken link instead of a theory:
            //   buttons never light  -> the press is not reaching us at all
            //   buttons light, captured no -> ImGui is eating the click
            //   captured yes, moves frozen -> no motion events in this mode
            //   moves climbing, applied frozen -> deltas rejected as oversized
            //   applied climbing, delta 0,0 -> the cursor mode reports no motion
            ImGui.Text($"  mouse  L{(_window.MouseLeftDown ? 1 : 0)} R{(_window.MouseRightDown ? 1 : 0)}   " +
                       $"captured {(_window.MouseCaptured ? "yes" : "no")}   cursor {_window.CursorModeName}");
            ImGui.Text($"  moves {_window.MouseMoveEvents}  applied {_window.MouseLookEvents}  " +
                       $"last delta ({_window.LastMouseDelta.X,6:F1},{_window.LastMouseDelta.Y,6:F1})");

            // If look is dead, raw cursor is the first thing to turn off, and it
            // now lives in Escape / Camera and controls with that sentence on it.
            ImGui.TextDisabled(
                $"  raw cursor {(_window.RawCursor ? "on" : "OFF")}   " +
                $"sensitivity x{_window.MouseSensitivity:F2}");

            ImGui.Separator();

            if (_controller is not null)
            {
                bool flying = _controller.Flying;
                if (ImGui.Checkbox("Fly (F)", ref flying)) _controller.Flying = flying;
            }

            ImGui.Checkbox("Show player capsule", ref _showPlayerMarker);

            if (_terrain is not null)
            {
                int mode = _terrain.DebugMode;
                if (ImGui.Combo("Shading", ref mode,
                        "Textured\0Normals\0UVs\0Flat\0Splat mask\0Untextured\0"))
                    _terrain.DebugMode = mode;

                float scale = _terrain.TextureScale;
                if (ImGui.SliderFloat("Texture repeat", ref scale, 1f, 32f))
                    _terrain.TextureScale = scale;

                if (_terrain.TileCount > 0)
                    ImGui.Text($"tileset textures {_terrain.FirstTileTextureCount}");
            }

            ImGui.Separator();
            ImGui.TextWrapped("W/S walk, A/D turn, Q/E strafe (holding RIGHT mouse swaps A/D to " +
                              "strafe). Arrow keys turn and walk, PgUp/PgDn look up and down, " +
                              "Shift walk, Space jump, F toggle fly, C collision " +
                              "(Space/Ctrl for height while flying, Shift boosts). " +
                              "LEFT mouse swings the camera around your character without turning him; " +
                              "RIGHT mouse turns him and the camera together; moving re-centres the " +
                              "camera behind him. Wheel to zoom, Esc for the game menu.");
            }
        }
        ImGui.End();

        // The Water Tuning and Foliage Tuning windows are gone: every knob in
        // both is now Escape / Graphics, under Water and Ground clutter, where it
        // persists instead of evaporating at exit. The methods that drew them are
        // deleted rather than left unreferenced - a dead HUD window is a second
        // place for a value to disagree with itself.
    }

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;

        _net?.Dispose();
        _glue?.Dispose();
        _creatures?.Dispose();

        try { _collisionBuildTask?.GetAwaiter().GetResult(); }
        catch { /* Shutdown must continue after a failed background build. */ }
        _gpuProfiler?.Dispose();
        _gpuProfiler = null;
        _skin?.Dispose();
        _skin = null;
        _character?.Dispose();
        _collisionDebug?.Dispose();
        _doodads?.Dispose();
        _liquid?.Dispose();
        _foliage?.Dispose();
        _wmo?.Dispose();
        _terrain?.Dispose();
        DisposeLoadingArt();
        _sky?.Dispose();
        _glow?.Dispose();
        _glueAdd?.Dispose();
        _uploads?.Dispose();
        _assetWorkers?.Dispose();

        // Renderer disposal joins any asset-preparation workers before the
        // extractor is detached and its shared archive handles are closed.
        AdtTerrainReader.StormLibExtractor = null;
        _particles?.Dispose();
        _mpq?.Dispose();
    }
}
