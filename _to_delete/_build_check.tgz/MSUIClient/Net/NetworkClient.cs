using System.Collections.Concurrent;
using System.Numerics;
using System.Threading;

namespace MSUIClient.Net;

// Top-level networking orchestrator: realmd logon -> world connect -> char enum
// -> PARK AT CHARACTER SELECT -> (app picks) -> player login -> in-world, on a
// background thread. Runs the ~30s keepalive ping and hands the game loop a
// thread-safe queue of inbound packets + a one-shot "entered world" signal.
//
// The character-select park is faithful to benilla (events.rs CharacterList: "the
// world socket is authenticated and parked at character select ... waits for the
// app's pick before CMSG_PLAYER_LOGIN moves the session into the world"). We do
// NOT auto-log-in a character; the app shows the roster and calls SelectCharacter.

public enum NetState
{
    Idle,
    ConnectingRealm,
    Authenticating,
    ConnectingWorld,
    CharacterSelect,   // parked: roster is up, waiting for the app's pick
    EnteringWorld,
    InWorld,
    Failed,
    Disconnected,
}

/// <summary>The server-authoritative pose to snap to on entering (or changing) world.</summary>
public readonly record struct EnterWorldInfo(uint Map, Vector3 Position, float Orientation);

/// <summary>Connection settings, built from ClientConfig by the app.</summary>
public sealed record NetSettings(
    string RealmdHost,
    int RealmdPort,
    int WorldPortFallback,
    string Account,
    string Password,
    string? RealmName = null,
    string? CharacterName = null,
    int TimeoutMs = 10000,
    bool WorldUsesRealmdHost = true);

public sealed class NetworkClient : IDisposable
{
    private readonly NetSettings _cfg;
    private readonly ConcurrentQueue<(ushort Opcode, byte[] Body)> _inbound = new();

    private Thread? _worker;
    private Timer? _pingTimer;
    private WorldSession? _session;
    private volatile bool _running;
    private uint _pingSeq;

    // Game-loop-visible state (all reads are cheap snapshots).
    public volatile NetState State = NetState.Idle;
    private volatile string _status = "offline";
    public string Status => _status;

    public ulong PlayerGuid { get; private set; }
    public string PlayerName { get; private set; } = "";
    public Character? Player { get; private set; }

    /// <summary>The human realm NAME from the realmlist (e.g. "Barrens Local (PVP)"), set once a realm is
    /// picked at logon. Empty before the first connection. The glue chrome shows this instead of host:port.</summary>
    public string RealmName { get; private set; } = "";

    /// <summary>The account roster, published when we reach CharacterSelect. Read by the select screen.</summary>
    public IReadOnlyList<Character> Characters { get; private set; } = Array.Empty<Character>();

    // Character-select park: the worker waits on _pick until the app calls SelectCharacter.
    private readonly ManualResetEventSlim _pick = new(false);
    private ulong _pickGuid;

    // Park action: the app either enters the world with a pick, or fires a character CREATE while
    // still parked at select (benilla carries both over the same pick channel).
    private enum ParkReq { None, Enter, Create, Delete }
    private volatile ParkReq _parkReq = ParkReq.None;
    private readonly object _createLock = new();
    private CharCreateParams _pendingCreate;
    private int _createResult = -1;   // -1 = none pending; else the SMSG_CHAR_CREATE result byte
    private ulong _pendingDelete;
    private int _deleteResult = -1;   // -1 = none pending; else the SMSG_CHAR_DELETE result byte

    private EnterWorldInfo? _pendingEnter;
    private readonly object _enterLock = new();

    private string _account;
    private string _password;

    public NetworkClient(NetSettings cfg)
    {
        _cfg = cfg;
        _account = cfg.Account;
        _password = cfg.Password;
    }

    public bool IsInWorld => State == NetState.InWorld;
    public bool AtCharacterSelect => State == NetState.CharacterSelect;

    /// <summary>Set credentials (from the login screen) and start connecting.</summary>
    public void Login(string account, string password)
    {
        _account = account;
        _password = password;
        Start();
    }

    /// <summary>Pick a character at the select screen — unblocks the worker to send CMSG_PLAYER_LOGIN.</summary>
    public void SelectCharacter(ulong guid)
    {
        _pickGuid = guid;
        _parkReq = ParkReq.Enter;
        _pick.Set();
    }

    /// <summary>Create a character while parked at select (benilla CharRequest::Create over the pick
    /// channel). The worker sends CMSG_CHAR_CREATE, waits for the result, and on success re-enums the
    /// roster; the app polls the result via <see cref="TryTakeCreateResult"/>.</summary>
    public void CreateCharacter(in CharCreateParams p)
    {
        lock (_createLock) { _pendingCreate = p; _createResult = -1; }
        _parkReq = ParkReq.Create;
        _pick.Set();
    }

    /// <summary>Delete a character while parked at select. Same channel as the create: the worker
    /// sends CMSG_CHAR_DELETE, waits for the result and re-enumerates the roster on success, so the
    /// row disappears without a reconnect. The app polls via <see cref="TryTakeDeleteResult"/>.</summary>
    public void DeleteCharacter(ulong guid)
    {
        lock (_createLock) { _pendingDelete = guid; _deleteResult = -1; }
        _parkReq = ParkReq.Delete;
        _pick.Set();
    }

    /// <summary>Take the last SMSG_CHAR_DELETE result once (game-thread poll). False if none pending.</summary>
    public bool TryTakeDeleteResult(out byte code)
    {
        lock (_createLock)
        {
            if (_deleteResult < 0) { code = 0; return false; }
            code = (byte)_deleteResult;
            _deleteResult = -1;
            return true;
        }
    }

    /// <summary>Take the last SMSG_CHAR_CREATE result once (game-thread poll). False if none pending.</summary>
    public bool TryTakeCreateResult(out byte code)
    {
        lock (_createLock)
        {
            if (_createResult < 0) { code = 0; return false; }
            code = (byte)_createResult;
            _createResult = -1;
            return true;
        }
    }

    /// <summary>
    /// Start a connection attempt. Safe to call again after a failed one.
    ///
    /// THE RETRY BUG (fixed 2026-07-29). This used to be `if (_running) return;`. A bad password makes
    /// RealmClient.Logon throw AuthRejectException(0x04); the worker catches it, calls Fail() and
    /// EXITS - but nothing ever cleared `_running`, so every later Login() hit that guard and silently
    /// did nothing. The login screen stayed up, the button did nothing, and there was no way to try
    /// again short of restarting the client (Nico: "if I type in the wrong password I don't get to try
    /// again ... the login just stops doing anything"). The flag was tracking "a worker was started",
    /// not "a worker is running", so gate on the THREAD instead - and wipe the previous attempt's
    /// state so a retry starts clean rather than on a half-open session.
    /// </summary>
    public void Start()
    {
        if (_worker is { IsAlive: true }) return;

        if (_worker is not null)
        {
            try { _worker.Join(250); } catch { }
            _worker = null;
        }
        ResetForNewAttempt();

        _running = true;
        _worker = new Thread(Run) { IsBackground = true, Name = "MSUI-Net" };
        _worker.Start();
    }

    /// <summary>Drop everything the previous attempt left behind, so a retry cannot inherit a stale
    /// roster, a half-open socket, a queued packet or a pending character pick.</summary>
    private void ResetForNewAttempt()
    {
        try { _pingTimer?.Dispose(); } catch { }
        _pingTimer = null;
        try { _session?.Dispose(); } catch { }
        _session = null;

        while (_inbound.TryDequeue(out _)) { }
        Characters = Array.Empty<Character>();
        Player = null;
        PlayerGuid = 0;
        PlayerName = "";
        RealmName = "";
        _pickGuid = 0;
        _parkReq = ParkReq.None;
        _pick.Reset();
        lock (_createLock) { _createResult = -1; _deleteResult = -1; }
        lock (_enterLock) _pendingEnter = null;

        State = NetState.Idle;
        _status = "connecting";
    }

    /// <summary>Drain inbound packets (call once per frame). Returns false when the queue is empty.</summary>
    public bool TryDequeue(out ushort opcode, out byte[] body)
    {
        if (_inbound.TryDequeue(out var p)) { opcode = p.Opcode; body = p.Body; return true; }
        opcode = 0; body = Array.Empty<byte>(); return false;
    }

    /// <summary>Non-null exactly once after entering or changing world — the pose the game loop teleports/loads to.</summary>
    public EnterWorldInfo? TakeEnterWorld()
    {
        lock (_enterLock)
        {
            var e = _pendingEnter;
            _pendingEnter = null;
            return e;
        }
    }

    // --- outbound pass-throughs (safe no-ops when not in world) ---------------------------------

    public void SendMovement(Op moveOp, MovementInfo info)
    {
        if (State == NetState.InWorld) { try { _session?.SendMovement(moveOp, info); } catch { /* dropped on disconnect */ } }
    }

    public void SetSelection(ulong guid) { try { _session?.SetSelection(guid); } catch { } }
    public void AttackSwing(ulong guid) { try { _session?.AttackSwing(guid); } catch { } }
    public void AttackStop() { try { _session?.AttackStop(); } catch { } }
    public void CreatureQuery(uint entry, ulong guid) { try { _session?.CreatureQuery(entry, guid); } catch { } }
    public void NameQuery(ulong guid) { try { _session?.NameQuery(guid); } catch { } }

    // --- worker ---------------------------------------------------------------------------------

    private void Run()
    {
        var timeout = TimeSpan.FromMilliseconds(_cfg.TimeoutMs);
        try
        {
            // 1. realmd logon.
            SetState(NetState.ConnectingRealm, $"connecting to realmd {_cfg.RealmdHost}:{_cfg.RealmdPort}");
            var logon = RealmClient.Logon(_cfg.RealmdHost, _cfg.RealmdPort, _account, _password, timeout);

            if (logon.Realms.Count == 0) { Fail("realm list is empty"); return; }
            RealmInfo realm = PickRealm(logon.Realms);
            RealmName = realm.Name;                 // published for the glue chrome (name, not host:port)
            var (worldHost, worldPort) = HostPort(realm.Address, _cfg.WorldPortFallback);
            // Private servers usually run mangosd on the same box as realmd, and the realmlist DB
            // often advertises an internal / unreachable IP (yours advertised 10.30.37.30). Prefer the
            // realmd host we already reached, keeping the advertised port.
            if (_cfg.WorldUsesRealmdHost && !string.IsNullOrWhiteSpace(_cfg.RealmdHost)
                && !string.Equals(worldHost, _cfg.RealmdHost, StringComparison.OrdinalIgnoreCase))
            {
                Console.WriteLine($"[net] realm advertises world {worldHost}:{worldPort}; using realmd host {_cfg.RealmdHost} instead");
                worldHost = _cfg.RealmdHost;
            }

            // 2. world connect + auth handshake.
            SetState(NetState.ConnectingWorld, $"connecting to world {worldHost}:{worldPort} ({realm.Name})");
            _session = WorldSession.Connect(worldHost, worldPort, _account, logon.SessionKey, timeout);

            // 3. character enum -> PARK at character select. We do NOT auto-log-in.
            SetState(NetState.Authenticating, "requesting character list");
            var chars = _session.CharEnum();
            Characters = chars;

            ulong wanted = 0;
            // Dev fast path only: if the config names a character, skip the screen (benilla's WOW_CHAR).
            if (!string.IsNullOrWhiteSpace(_cfg.CharacterName))
                wanted = chars.FirstOrDefault(c =>
                    string.Equals(c.Name, _cfg.CharacterName, StringComparison.OrdinalIgnoreCase))?.Guid ?? 0;

            if (wanted == 0)
            {
                // Park at character select. The app may pick a character to enter the world, or fire a
                // CREATE while still parked (benilla runs both over the pick channel). A create is
                // serviced here on the worker: send CMSG_CHAR_CREATE, wait for the result, and on
                // success re-enum so the new row appears - then stay parked for the next action.
                while (true)
                {
                    SetState(NetState.CharacterSelect,
                        chars.Count == 0 ? "no characters on this account" : $"character select - {chars.Count} character(s)");
                    _pick.Reset();
                    _pick.Wait();                 // parked until SelectCharacter / CreateCharacter / Stop
                    if (!_running) return;

                    ParkReq req = _parkReq;
                    _parkReq = ParkReq.None;
                    if (req == ParkReq.Create)
                    {
                        CharCreateParams create;
                        lock (_createLock) create = _pendingCreate;
                        SetState(NetState.CharacterSelect, $"creating {create.Name}...");
                        byte code = _session.CreateCharacter(create);
                        if (code == 0x2E)                 // CHAR_CREATE_SUCCESS: refresh the roster first
                        {
                            chars = _session.CharEnum();
                            Characters = chars;
                        }
                        lock (_createLock) _createResult = code;   // publish AFTER the roster is fresh
                        continue;                         // stay parked for the next pick/create
                    }
                    if (req == ParkReq.Delete)
                    {
                        ulong doomed;
                        lock (_createLock) doomed = _pendingDelete;
                        SetState(NetState.CharacterSelect, "deleting character...");
                        byte code = _session.DeleteCharacter(doomed);
                        if (code == 0x39)                 // CHAR_DELETE_SUCCESS: refresh the roster
                        {
                            chars = _session.CharEnum();
                            Characters = chars;
                        }
                        lock (_createLock) _deleteResult = code;
                        continue;                         // stay parked
                    }

                    wanted = _pickGuid;
                    if (wanted != 0) break;
                }
            }

            Character? pick = chars.FirstOrDefault(c => c.Guid == wanted);
            if (pick is null) { Fail("selected character not found in roster"); return; }
            Player = pick;
            PlayerGuid = pick.Guid;
            PlayerName = pick.Name;

            // 4. enter world.
            SetState(NetState.EnteringWorld, $"entering world as {pick.Name} (L{pick.Level})");
            _session.PlayerLogin(pick.Guid);

            // 5. stream. LOGIN_VERIFY_WORLD flips us to InWorld; everything else is queued for the app.
            ReadLoop();
        }
        catch (Exception ex) when (_running)
        {
            Fail(ex.Message);
        }
        catch (Exception)
        {
            // shutting down — swallow
        }
        finally
        {
            // The worker is DONE. Drop the flag here and nowhere else, so Start() can run a fresh
            // attempt after a failure - the missing half of the retry bug documented on Start().
            // Ordering is safe: the `when (_running)` filters above are evaluated before this runs,
            // so a genuine error still reports through Fail() and a Stop() still reads as shutdown.
            _running = false;
        }
    }

    private void ReadLoop()
    {
        var session = _session!;
        while (_running)
        {
            (ushort opcode, byte[] body) = session.ReceivePacket();
            switch ((Op)opcode)
            {
                case Op.SMSG_LOGIN_VERIFY_WORLD:
                    {
                        var r = new PacketReader(body);
                        var info = new EnterWorldInfo(r.ReadU32(), r.ReadVector3(), r.ReadF32());
                        SetEnter(info);
                        SetState(NetState.InWorld, $"in world: {PlayerName} - map {info.Map} at ({info.Position.X:F0}, {info.Position.Y:F0}, {info.Position.Z:F0})");
                        session.SetActiveMover(PlayerGuid);   // become the confirmed mover
                        StartPing();
                        break;
                    }
                case Op.SMSG_NEW_WORLD:
                    {
                        var r = new PacketReader(body);
                        var info = new EnterWorldInfo(r.ReadU32(), r.ReadVector3(), r.ReadF32());
                        session.WorldportAck();
                        SetEnter(info);
                        _status = $"changing to map {info.Map}";
                        break;
                    }
            }
            _inbound.Enqueue((opcode, body));

            // Keep the queue from growing without bound if the app stops draining.
            while (_inbound.Count > 4096 && _inbound.TryDequeue(out _)) { }
        }
    }

    private void StartPing()
    {
        _pingTimer ??= new Timer(_ =>
        {
            try { _session?.Ping(unchecked(_pingSeq++), 0); } catch { /* disconnect handled by read loop */ }
        }, null, 30_000, 30_000);
    }

    private void SetEnter(EnterWorldInfo info)
    {
        lock (_enterLock) _pendingEnter = info;
    }

    private void SetState(NetState s, string status)
    {
        State = s;
        _status = status;
        Console.WriteLine($"[net] {s}: {status}");
    }

    private void Fail(string reason)
    {
        State = NetState.Failed;
        _status = $"failed: {reason}";
        Console.WriteLine($"[net] FAILED: {reason}");
    }

    private RealmInfo PickRealm(List<RealmInfo> realms)
    {
        if (!string.IsNullOrWhiteSpace(_cfg.RealmName))
            foreach (var r in realms)
                if (string.Equals(r.Name, _cfg.RealmName, StringComparison.OrdinalIgnoreCase)) return r;
        return realms[0];
    }

    /// <summary>Split "host:port" (realm address). A bare host or non-numeric suffix keeps the default port.</summary>
    public static (string Host, int Port) HostPort(string address, int defaultPort)
    {
        int i = address.LastIndexOf(':');
        if (i > 0 && i < address.Length - 1 && !address.AsSpan(0, i).Contains(':')
            && int.TryParse(address.AsSpan(i + 1), out int port))
            return (address[..i], port);
        return (address, defaultPort);
    }

    public void Stop()
    {
        _running = false;
        _pick.Set();                  // wake a worker parked at character select so it can exit
        try { _pingTimer?.Dispose(); } catch { }
        _pingTimer = null;
        try { _session?.Dispose(); } catch { } // unblocks the read loop with an IOException
        _session = null;
        try { _worker?.Join(1000); } catch { }
        _worker = null;
        Characters = Array.Empty<Character>();
        if (State != NetState.Failed) State = NetState.Disconnected;
    }

    public void Dispose() => Stop();
}
